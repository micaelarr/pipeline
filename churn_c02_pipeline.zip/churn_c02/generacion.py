"""PIPELINE DE GENERACIÓN (offline, Google Cloud). Orquesta las etapas de etapas.py:
   preparar -> estrategia A|B|C|D -> optuna -> política W -> política W_R | W_T -> consolidar (bundle + dashboard)
paralelo=False: todo en este proceso (notebook o prueba). paralelo=True: las estrategias y las políticas W_R/W_T se lanzan como procesos
separados al mismo tiempo (en la nube se pueden mandar a VMs distintas con gcp_paralelo.sh). Con forzar=False se saltean etapas ya hechas
(reanuda una corrida cortada)."""
import os, subprocess, sys, time
from pathlib import Path
from .config import C
from . import bundle, etapas
from .estrategias import ESTRATEGIAS

def _activas():
    from .externos import cargar_ipc
    return [e for e in ESTRATEGIAS if e != "D" or cargar_ipc()]

def run(run_id=None, paralelo=False, forzar=False, log=print):
    run_id = run_id or C.RUN or bundle.ahora(); os.environ["C02_RUN"] = run_id; T0 = time.time()
    def pendiente(nombre, arg=None):
        key = nombre if not arg else f"{'estrategia' if nombre == 'estrategia' else nombre}_{arg}"
        key = key if nombre != "optuna" else "optuna"
        return forzar or not etapas.hecho(run_id, key)
    def correr(grupo):
        grupo = [(n, a) for n, a in grupo if pendiente(n, a)]
        if not grupo: return
        if not paralelo or len(grupo) == 1:
            for n, a in grupo: etapas.ejecutar(n, a, run_id, log)
            return
        raiz = Path(__file__).resolve().parent.parent
        for i in range(0, len(grupo), max(1, C.PARALELO_MAX)):        # lotes de PARALELO_MAX procesos (cada uno carga los datos en memoria)
            ps = [subprocess.Popen([sys.executable, "-u", "-m", "churn_c02.etapas", n] + ([a] if a else []) + ["--run", run_id], cwd=raiz)
                  for n, a in grupo[i:i + max(1, C.PARALELO_MAX)]]
            fallas = [p.args for p in ps if p.wait() != 0]
            assert not fallas, f"fallaron etapas: {fallas} (si fue por memoria, relanzá con C02_PARALELO_MAX=2: se retoma desde lo ya hecho)"
    correr([("preparar", None)])
    correr([("estrategia", e) for e in _activas()])
    correr([("optuna", None)])
    correr([("politica", "W")])
    correr([("politica", "W_R"), ("politica", "W_T")])
    correr([("consolidar", None)])
    log(f"Run {run_id} listo en {etapas.art_dir(run_id)} ({(time.time() - T0) / 60:.1f} min)")
    return etapas.art_dir(run_id)
