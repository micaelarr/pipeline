"""Arma el dashboard HTML (un solo archivo, sin dependencias externas) con lo que dejaron la generación y la producción."""
import json, datetime
from pathlib import Path
import numpy as np
from .config import C
from . import io_, narrador
from .estrategias import COLORES

CLAVES = ("auc", "ap", "ganancia_opt", "frac_opt", "lift10", "calib", "psi_score", "R1", "R2", "R3", "frac_R2", "frac_R3", "frac_p025", "ganancia_p025",
          "n", "n_pos", "tasa", "curva", "roc", "deciles_tasa", "deciles_p", "score", "p_medio", "train_hasta")

def _heat(drift, meses, n=22):
    mx = {}
    for m in meses:
        for k, v in (drift.get(str(m)) or {}).get("psi_todas", {}).items(): mx[k] = max(mx.get(k, 0), v)
    vars_ = [k for k, _ in sorted(mx.items(), key=lambda x: -x[1])[:n]]
    z = [[(drift.get(str(m)) or {}).get("psi_todas", {}).get(k) for m in meses] for k in vars_]
    return dict(meses=meses, vars=vars_, nombres=[narrador.nombre_humano(v) for v in vars_], z=z)

def _cal(ch):
    if not ch: return {}
    return dict(alertas=ch.get("alertas", [])[:10], n_alertas=len(ch.get("alertas", [])), n_critica=ch.get("n_critica", 0), rotas=ch.get("rotas", []),
                correcciones=ch.get("correcciones", [])[:10], resumen=ch.get("resumen", {}))

def construir_datos(art):
    bt = io_.leer_json(io_.unir(art, "backtest.json")); man = bt["manifest"]
    hp = io_.unir(art, "produccion", "historial.jsonl")
    prod = [json.loads(l) for l in io_.leer_texto(hp).splitlines() if l.strip()] if io_.existe(hp) else []
    as_of = max([r["mes"] for r in bt["resultados"]] + [p["mes"] for p in prod])
    por_mes = {}
    for r in bt["resultados"]: por_mes.setdefault(r["mes"], []).append(r)
    meses = []
    for mes in sorted(por_mes):
        rs = por_mes[mes]; blq = rs[0]["bloque"]; k = str(mes)
        m = dict(mes=mes, bloque=blq, evento=bt["eventos"].get(k), v={r["variante"]: {c: r[c] for c in CLAVES if c in r} for r in rs},
                 calidad=_cal(bt.get("calidad", {}).get(k)), drift={a: b for a, b in bt["drift"][k].items() if a != "psi_todas"}, alarma=bt["alarmas"].get(k, dict(nivel=0, motivos=[])),
                 accion=bt["acciones"].get(k, dict(accion="score", por_que="Mes de entrenamiento/validación (walk-forward).")))
        if blq == "wf": m["drift"]["psi_score"] = rs[0].get("psi_score")
        m.update(narrador.redactar(m, as_of)); meses.append(m)
    for p in prod:
        if p["mes"] in por_mes:      # mes ya evaluado en el backtest: se marca, no se duplica
            next(m for m in meses if m["mes"] == p["mes"])["prod"] = True; continue
        m = dict(mes=p["mes"], bloque="prod", evento=bt["eventos"].get(str(p["mes"])), v={}, calidad=_cal(p.get("calidad")), drift={a: b for a, b in p["drift"].items()}, alarma=p["alarma"], accion=p["decision"])
        if p.get("realizado"): m["v"]["W"] = {c: p["realizado"].get(c) for c in CLAVES if c in p["realizado"]}
        m.update(vivo=narrador.historia_vivo(m), postmortem="Mes procesado en producción; la clase llega 2 meses después." if not p.get("realizado") else narrador.historia_post(m, as_of))
        meses.append(m)
    oot, wf = [m for m in meses if m["bloque"] == "oot"], [m for m in meses if m["bloque"] == "wf"]
    todos_drift = {**bt["drift"], **{str(p["mes"]): dict(psi_todas=p.get("psi_todas", {})) for p in prod}}
    cols_heat = [m["mes"] for m in meses if m["bloque"] in ("oot", "prod")]
    return dict(
        meta=dict(run_id=man["run_id"], generado=datetime.datetime.now().strftime("%Y-%m-%d %H:%M"), train=man["train"], ganadora=man["ganadora"],
                  params=man["params"], rondas=man["rondas"], optuna=man["optuna"], frac=man["frac_recomendada"], meseta=man["meseta"], umbrales=man["umbrales"],
                  ganancia=man["ganancia"], p_eq=C.P_EQ, pandemia=bt["pandemia"], limite_s=C.LIMITE_SCORING_S, as_of=as_of),
        variantes={k: dict(nombre=v, color=COLORES.get(k, "#555")) for k, v in bt["nombres"].items()},
        meses=meses, heat=_heat(todos_drift, cols_heat), capitulos=narrador.capitulos(oot, wf, bt["pandemia"]), importancias=bt["importancias"],
        seleccion=bt["seleccion_wf"], auditoria=bt["auditoria"], reentrenos=bt["reentrenos"], fr_grid=bt["fr_grid"], curva_wf=bt["curva_wf_media"],
        tiempos=bt["tiempos"], produccion=[{k: v for k, v in p.items() if k not in ("psi_todas",)} for p in prod],
        llm=C.LLM if C.LLM != "none" else None, ipc=bt.get("ipc", {}).get("activo", False), estrategias=man.get("estrategias", []))

def generar(art, log=print):
    D = construir_datos(art)
    html = Path(__file__).with_name("plantilla.html").read_text(encoding="utf-8").replace("/*__DATA__*/", "const D=" + json.dumps(D, ensure_ascii=False, default=float) + ";")
    io_.escribir_texto(io_.unir(art, "dashboard.html"), html)
    log(f"Dashboard: {io_.unir(art, 'dashboard.html')}")
    return html
