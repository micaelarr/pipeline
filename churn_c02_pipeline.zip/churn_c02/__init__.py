"""churn_c02: pipeline de generación + producción."""
