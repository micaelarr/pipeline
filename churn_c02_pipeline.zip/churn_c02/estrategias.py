"""Estrategias (A baseline / B historia / C robusta) y su entrenamiento. Los hiperparámetros son un input: recalibrar = mismos
parámetros, otros datos."""
from dataclasses import dataclass, field
import numpy as np, pandas as pd
import lightgbm as lgb
from .config import C
from .datos import CLASE, mes_menos
from .variables import columnas_de_nivel, grupo_de

ESTRATEGIAS = {
    "A": dict(nombre="A · Baseline (variables crudas)", nivel="raw", decay=None, semillas=[101]),
    "B": dict(nombre="B · + lags, deltas, razones y ventana de 3 meses", nivel="hist", decay=None, semillas=[101]),
    "C": dict(nombre="C · B + percentiles + pesos por mes + 3 semillas", nivel="full", decay=C.DECAY, semillas=C.SEMILLAS_C),
    "D": dict(nombre="D · B + montos deflactados por IPC", nivel="ipc", decay=None, semillas=[101]),
}

def activas(spec):
    """D sólo existe si hay IPC; sin IPC se comparan A, B y C."""
    return {k: v for k, v in ESTRATEGIAS.items() if k != "D" or spec.get("ipc")}
COLORES = {"A": "#8a94a6", "B": "#2f7de1", "C": "#e8590c", "D": "#0b7285", "W": "#12a150", "W_R": "#9c36b5", "W_T": "#d6336c"}

def corregir(p):
    """Deshace el submuestreo de CONTINUA. Si cada negativo se conserva con probabilidad b, las chances reales son chances_muestra * b:
    p_real = b*p / (b*p + (1-p)). Deja las probabilidades en escala real (el corte p > 2,5% tiene sentido y la calibración ~ 1)."""
    b = C.FRAC_CONT_ENTRENO
    return b * p / (b * p + (1 - p))

class Almacen:
    """Tablas de entrenamiento por mes (negativos submuestreados) + muestra de referencia sin sesgo para el perfil de deriva."""
    def __init__(self, constructor, seed=0):
        self.k, self.tr, self.ref, self.cols, self.rng = constructor, {}, {}, None, np.random.default_rng(seed)

    def preparar(self, meses):
        for m in sorted(meses):
            if m in self.tr or m not in self.k.fuente: continue
            clase = self.k.fuente[m][CLASE]
            if clase.isna().all(): continue
            X = self.k.construir(m); self.cols = self.cols or list(X.columns)
            ok = clase.notna().to_numpy(); y = (clase == "BAJA+2").to_numpy()
            # BAJA+2 completos; TODOS los negativos (CONTINUA y BAJA+1) a la misma tasa. Antes BAJA+1 se guardaba entero y quedaba
            # 3,3 veces sobrerrepresentado entre los negativos: la corrección de probabilidad (que supone una tasa única) quedaba sesgada.
            keep = ok & ((clase == "BAJA+2") | (self.rng.random(len(clase)) < C.FRAC_CONT_GUARDADA)).to_numpy()
            self.tr[m] = (X[keep], y[keep].astype("int8"))
            self.ref[m] = X.iloc[self.rng.permutation(len(X))[:5000]]
            self.k.liberar(mes_menos(m, 2)); del X

    def meses_hasta(self, hasta, ventana=None):
        ms = sorted(m for m in self.tr if m <= hasta)
        return ms[-ventana:] if ventana else ms

@dataclass
class Modelo:
    boosters: list; cols: list; nivel: str; train_hasta: int; meses: list; params: dict; rondas: int; id: str = ""
    def predecir(self, X):
        return corregir(np.mean([b.predict(X[self.cols]) for b in self.boosters], axis=0))
    def importancias(self):
        g = pd.Series(np.sum([b.feature_importance("gain") for b in self.boosters], axis=0), index=self.cols)
        return g / g.sum()

def entrenar(almacen, estrategia, train_hasta, params=None, rondas=None, ventana=None, id=""):
    """Entrena la estrategia con los meses con clase conocida ≤ train_hasta. params/rondas = hiperparámetros (None = default)."""
    e = ESTRATEGIAS[estrategia] if isinstance(estrategia, str) else estrategia
    meses = almacen.meses_hasta(train_hasta, ventana)
    assert meses, f"no hay meses de entrenamiento ≤ {train_hasta}"
    cols = columnas_de_nivel(almacen.cols, e["nivel"])
    p = {**C.LGB_DEFAULT, **(params or {}), "num_threads": C.NUM_HILOS}; rondas = int(rondas or C.N_RONDAS_DEFAULT)
    bs = []
    for s in e["semillas"]:
        r = np.random.default_rng(s); Xs, ys, ws = [], [], []
        for i, m in enumerate(meses):
            X, y = almacen.tr[m]
            k = (y == 1) | (r.random(len(y)) < C.FRAC_CONT_ENTRENO / C.FRAC_CONT_GUARDADA)
            Xs.append(X.loc[k.astype(bool), cols]); ys.append(y[k])
            ws.append(np.full(int(k.sum()), e["decay"] ** (len(meses) - 1 - i) if e["decay"] else 1.0, dtype="float32"))
        bs.append(lgb.train({**p, "seed": s}, lgb.Dataset(pd.concat(Xs), label=np.concatenate(ys), weight=np.concatenate(ws)), num_boost_round=rondas))
    return Modelo(bs, cols, e["nivel"], train_hasta, meses, {k: v for k, v in p.items() if k != "num_threads"}, rondas, id)
