"""Datos externos: IPC. Qué hacer con las variables en pesos: la estrategia D las expresa en pesos constantes del último mes de
entrenamiento (factor = IPC_base / IPC_mes); la C usa percentiles dentro del mes. El dashboard las compara."""
import numpy as np, pandas as pd
from .config import C
from . import io_
from .datos import mes_menos

def cargar_ipc(uri=None):
    """dict mes -> nivel de IPC, o None si no hay archivo (la estrategia D queda desactivada)."""
    uri = uri or C.IPC_URI
    if not uri or not io_.existe(uri): return None
    with io_.abrir(uri, "rb") as f: df = pd.read_csv(f)
    df = df.rename(columns={c: c.strip().lower() for c in df.columns})
    assert {"foto_mes", "ipc"} <= set(df.columns), "el IPC debe tener columnas foto_mes e ipc"
    return {int(m): float(v) for m, v in zip(df.foto_mes, df.ipc)}

def factores(ipc, base_mes, meses):
    """dict str(mes) -> factor para llevar pesos de `mes` a pesos de `base_mes`. Meses sin IPC se extrapolan con la inflación
    mensual promedio de los últimos 3 meses conocidos (quedan listados en 'extrapolados')."""
    niveles, ext = dict(ipc), []
    for m in sorted(meses):
        if m in niveles: continue
        prev = [k for k in niveles if k < m]
        if len(prev) < 4: continue
        ks = sorted(prev)[-4:]; g = np.mean([niveles[ks[i + 1]] / niveles[ks[i]] for i in range(3)])
        n = 0; cur = ks[-1]
        while cur < m: cur = mes_menos(cur, -1); n += 1
        niveles[m] = niveles[ks[-1]] * g ** n; ext.append(m)
    b = niveles[base_mes]
    f = {str(m): b / niveles[m] for m in meses if m in niveles}
    f["_extrapolados"] = ext
    return f
