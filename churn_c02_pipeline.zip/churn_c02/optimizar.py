"""Optuna: sólo en el pipeline de GENERACIÓN (y en 'reentrenar'). Validación temporal con gap: cada mes de validación v se
puntúa con un modelo entrenado con clase conocida ≤ v-GAP. Los meses de validación están dentro de la ventana de entrenamiento
(2019); 2020 nunca interviene en la elección de parámetros."""
import time
import numpy as np, pandas as pd
from .config import C
from .datos import mes_menos, CLASE
from .estrategias import entrenar, Modelo, ESTRATEGIAS
from .metricas import metricas

def _espacio(t):
    return dict(learning_rate=t.suggest_float("learning_rate", 0.01, 0.1, log=True),
                num_leaves=t.suggest_int("num_leaves", 8, 256, log=True),
                min_data_in_leaf=t.suggest_int("min_data_in_leaf", 20, 2000, log=True),
                feature_fraction=t.suggest_float("feature_fraction", 0.05, 0.8),
                bagging_fraction=t.suggest_float("bagging_fraction", 0.5, 1.0),
                lambda_l2=t.suggest_float("lambda_l2", 1e-3, 100, log=True)), t.suggest_int("rondas", 100, 600)

def optimizar(almacen, estrategia, n_trials=None, storage=None, nombre="estudio", valid_meses=None, metrica=None, hasta=None, log=print, inicial=None):
    """Devuelve dict(params, rondas, valor, trials(DataFrame)). `hasta`: último mes con clase usable (reentrenar: mes-GAP)."""
    import optuna
    n_trials, metrica = n_trials or C.OPTUNA_TRIALS, metrica or C.OPTUNA_METRICA
    valid = [v for v in (valid_meses or C.OPTUNA_VALID) if (hasta is None or v <= hasta)]
    assert valid, "sin meses de validación"
    # Una sola semilla durante la búsqueda (la C usa 3 en el modelo final): los hiperparámetros se transfieren y la BO cuesta 1/3.
    e = dict(ESTRATEGIAS[estrategia] if isinstance(estrategia, str) else estrategia); e["semillas"] = e["semillas"][:1]
    completos = {}
    for v in valid:                       # features completas del mes de validación (sin submuestreo), se arman una vez
        X = almacen.k.construir(v); clase = almacen.k.fuente[v][CLASE]; ok = clase.notna().to_numpy()
        completos[v] = (X[ok], (clase[ok] == "BAJA+2").to_numpy().astype(int))

    def objetivo(trial):
        params, rondas = _espacio(trial); vals = []
        for i, v in enumerate(valid):
            m = entrenar(almacen, e, mes_menos(v, C.GAP), params, rondas)
            X, y = completos[v]; r = metricas(y, m.predecir(X))
            vals.append(r["auc"] if metrica == "auc" else r["ganancia_opt"] / 1e6)
            trial.report(float(np.mean(vals)), i)
            if i < len(valid) - 1 and trial.should_prune(): raise optuna.TrialPruned()   # corta trials malos tras el 1er mes
        return float(np.mean(vals))

    estudio = optuna.create_study(direction="maximize", study_name=nombre, storage=storage, load_if_exists=True,
                                  sampler=optuna.samplers.TPESampler(seed=42),
                                  pruner=optuna.pruners.MedianPruner(n_startup_trials=8, n_warmup_steps=0))
    if len(estudio.trials) == 0:          # arranque en caliente: el primer punto es el campeón actual (reentrenar) o el default
        d = {**C.LGB_DEFAULT, **(inicial[0] if inicial else {})}
        estudio.enqueue_trial(dict(learning_rate=d["learning_rate"], num_leaves=d["num_leaves"], min_data_in_leaf=d["min_data_in_leaf"],
                                   feature_fraction=d["feature_fraction"], bagging_fraction=d["bagging_fraction"], lambda_l2=d["lambda_l2"],
                                   rondas=int(inicial[1]) if inicial else C.N_RONDAS_DEFAULT))
    t0 = time.time()
    faltan = max(0, n_trials - len(estudio.trials))
    estudio.optimize(objetivo, n_trials=faltan, timeout=C.OPTUNA_TIMEOUT_S)
    log(f"  Optuna: {len(estudio.trials)} trials en {time.time() - t0:.0f}s | mejor {metrica} = {estudio.best_value:.4f}")
    bp = dict(estudio.best_params); rondas = bp.pop("rondas")
    v0 = estudio.trials[0].value
    return dict(params=bp, rondas=rondas, valor=float(estudio.best_value), valor_default=float(v0) if v0 is not None else float("nan"),
                trials=estudio.trials_dataframe())
