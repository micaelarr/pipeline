"""E/S que funciona igual con rutas locales y gs:// (requiere gcsfs en la VM de Google Cloud)."""
import json, os, pickle

def es_remota(uri): return "://" in str(uri)

def unir(base, *partes):
    base = str(base).rstrip("/\\")
    return "/".join([base, *[str(p).strip("/\\") for p in partes]]) if es_remota(base) else os.path.join(base, *map(str, partes))

def abrir(uri, modo="rb"):
    if es_remota(uri):
        import fsspec
        return fsspec.open(str(uri), modo).open()
    if "w" in modo or "a" in modo: os.makedirs(os.path.dirname(os.path.abspath(uri)), exist_ok=True)
    return open(uri, modo, **({} if "b" in modo else {"encoding": "utf-8"}))

def existe(uri):
    if es_remota(uri):
        import fsspec
        fs, p = fsspec.core.url_to_fs(str(uri)); return fs.exists(p)
    return os.path.exists(uri)

def escribir_texto(uri, s):
    with abrir(uri, "w") as f: f.write(s)

def leer_texto(uri):
    with abrir(uri, "r") as f: return f.read()

def escribir_json(uri, obj): escribir_texto(uri, json.dumps(obj, ensure_ascii=False, indent=1, default=float))
def leer_json(uri): return json.loads(leer_texto(uri))

def escribir_pickle(uri, obj):
    with abrir(uri, "wb") as f: pickle.dump(obj, f)

def leer_pickle(uri):
    with abrir(uri, "rb") as f: return pickle.load(f)

def escribir_csv(uri, df, **kw):
    with abrir(uri, "w") as f: df.to_csv(f, **kw)
