"""Variables. Sólo miran hacia atrás (mes, mes-1, mes-2): ninguna usa información del futuro."""
import numpy as np, pandas as pd
from .datos import mes_menos, ID, MES, CLASE

NIVELES = ["raw", "hist", "ipc", "full"]   # raw = crudas (A) | hist = + lags/deltas/razones/ventana 3m (B) | ipc = hist + montos reales (D) | full = hist + percentiles (C)

def definir_spec(columnas):
    base = [c for c in columnas if c not in (ID, MES, CLASE)]
    excluir = {"cliente_edad", "cliente_antiguedad", "cliente_vip", "cdescubierto_preacordado"}
    mag = [c for c in base if c[0] in "mc" and not c.startswith(("Visa_", "Master_")) and c not in excluir]
    fechas = [c for c in base if c.split("_", 1)[-1].lower() in FECHAS]
    return dict(base=base, mag=mag, montos=[c for c in mag if c.startswith("m")], fechas=fechas)

# Variables de calendario de las tarjetas: vienen como días contados desde una fecha que depende del mes (la moda de fultimo_cierre
# salta 1, 2, 5, 0, 3, 6 de un mes a otro; Fvencimiento y fechaalta corren ~30 por mes). Así como vienen, el modelo y el monitor
# "reconocen el mes" (AUC adversarial = 1,0 incluso dentro de 2019). Se expresan relativas a la moda del propio mes.
FECHAS = {"fultimo_cierre", "finiciomora", "fvencimiento", "fechaalta"}

def normalizar_fechas(df, spec):
    """En el lugar: fecha -> fecha - moda del mes (corte transversal del propio mes, disponible al puntuar; no mira otros meses)."""
    for c in spec.get("fechas", []):
        if c in df.columns and df[c].notna().any():
            df[c] = (df[c] - df[c].mode().iloc[0]).astype("float32")
    return df

def razon(a, b):
    with np.errstate(divide="ignore", invalid="ignore"):
        return np.where(b == 0, np.nan, a / b).astype("float32")

class Constructor:
    """Arma variables de un mes a partir de `fuente` (dict mes -> DataFrame por cliente) que tenga ese mes y los 2 anteriores."""
    def __init__(self, spec, fuente=None):
        self.spec, self.fuente, self._pct = spec, fuente if fuente is not None else {}, {}

    def percentiles(self, mes):
        """Percentil (-100..100; cero fijo) de cada monto dentro del mes, sobre TODOS los clientes del mes."""
        if mes not in self._pct:
            d = self.fuente[mes][self.spec["montos"]]
            pos, neg = d.where(d > 0).rank(pct=True).fillna(0), (-d).where(d < 0).rank(pct=True).fillna(0)
            self._pct[mes] = (100 * (pos - neg)).where(d.notna()).astype("float32")
        return self._pct[mes]

    def liberar(self, antes_de):
        for m in [m for m in self._pct if m < antes_de]: del self._pct[m]

    def construir(self, mes):
        """Todas las variables ('full'); cada nivel es un subconjunto de columnas (ver columnas_de_nivel)."""
        sp, src = self.spec, self.fuente
        cur = src[mes]; mag = sp["mag"]
        X = cur[sp["base"]].copy()
        ant = [src.get(mes_menos(mes, k)) for k in (1, 2)]
        c = cur[mag].to_numpy("float32")
        l1, l2 = [np.full_like(c, np.nan) if a is None else a.reindex(cur.index)[mag].to_numpy("float32") for a in ant]
        v = np.stack([c, l1, l2]); prom, mx, mn = np.nanmean(v, 0), np.nanmax(v, 0), np.nanmin(v, 0)
        h = {}
        for i, col in enumerate(mag):
            h[f"{col}_lag1"], h[f"{col}_lag2"] = l1[:, i], l2[:, i]
            h[f"{col}_delta1"], h[f"{col}_delta2"] = c[:, i] - l1[:, i], c[:, i] - l2[:, i]
            h[f"{col}_ratiolag1"], h[f"{col}_avg3"] = razon(c[:, i], l1[:, i]), prom[:, i]
            h[f"{col}_ratioavg3"], h[f"{col}_max3"], h[f"{col}_min3"] = razon(c[:, i], prom[:, i]), mx[:, i], mn[:, i]
            h[f"{col}_ratiomax3"] = razon(c[:, i], mx[:, i])
        X = pd.concat([X, pd.DataFrame(h, index=cur.index).astype("float32")], axis=1)
        p = self.percentiles(mes)
        if ant[0] is not None and mes_menos(mes, 1) in src:
            p1 = self.percentiles(mes_menos(mes, 1)).reindex(cur.index)
        else:
            p1 = pd.DataFrame(np.nan, index=cur.index, columns=sp["montos"], dtype="float32")
        ph = pd.concat([p.add_prefix("pct_"), (p - p1.values).add_prefix("pctdelta1_"), p1.add_prefix("pctlag1_")], axis=1)
        X = pd.concat([X, ph.astype("float32")], axis=1)
        if sp.get("ipc"):                                   # montos en pesos constantes (factor = IPC base / IPC del mes)
            f = lambda m: sp["ipc"].get(str(m), np.nan)
            ix = [mag.index(m_) for m_ in sp["montos"]]
            r0, r1, r2 = c[:, ix] * f(mes), l1[:, ix] * f(mes_menos(mes, 1)), l2[:, ix] * f(mes_menos(mes, 2))
            ravg = np.nanmean(np.stack([r0, r1, r2]), 0)
            rr = {}
            for j, col in enumerate(sp["montos"]):
                rr[f"real_{col}"], rr[f"real_{col}_lag1"], rr[f"real_{col}_delta1"], rr[f"real_{col}_avg3"] = r0[:, j], r1[:, j], r0[:, j] - r1[:, j], ravg[:, j]
            X = pd.concat([X, pd.DataFrame(rr, index=cur.index).astype("float32")], axis=1)
        return X

_SUF = ("_ratiolag1", "_ratioavg3", "_ratiomax3", "_delta1", "_delta2", "_lag1", "_lag2", "_avg3", "_max3", "_min3")
_PRE = ("pctdelta1_", "pctlag1_", "pct_", "real_")

def base_de(col):
    """Variable cruda de la que deriva una columna (para atribuirle importancia y PSI)."""
    for p in _PRE:
        if col.startswith(p): col = col[len(p):]; break
    for s in _SUF:
        if col.endswith(s): return col[:-len(s)]
    return col

def grupo_de(col):
    if col.startswith("real_"): return "montos reales (IPC)"
    if col.startswith("pct"): return "percentil dentro del mes"
    for suf, g in (("_lag1", "lags"), ("_lag2", "lags"), ("_delta1", "deltas"), ("_delta2", "deltas"), ("_ratiolag1", "razones"),
                   ("_ratioavg3", "razones"), ("_ratiomax3", "razones"), ("_avg3", "ventana 3 meses"), ("_max3", "ventana 3 meses"),
                   ("_min3", "ventana 3 meses")):
        if col.endswith(suf): return g
    return "crudas"

def columnas_de_nivel(columnas_full, nivel):
    excl = {"raw": ("lags", "deltas", "razones", "ventana 3 meses", "percentil dentro del mes", "montos reales (IPC)"),
            "hist": ("percentil dentro del mes", "montos reales (IPC)"), "ipc": ("percentil dentro del mes",),
            "full": ("montos reales (IPC)",)}[nivel]
    return [c for c in columnas_full if grupo_de(c) not in excl]
