"""Chequeos de calidad de datos -> alertas -> correcciones. Se usan igual en generación y en producción.
Flujo: Input -> FE -> CHEQUEOS (nulos, ceros, constantes, meses rotos, columnas, filas, duplicados, PSI ponderado por importancia)
       -> ALERTAS (dashboard) -> CORRECCIONES (variable rota -> NaN en ese mes; columna faltante -> columna NaN)."""
import numpy as np, pandas as pd
from .config import C
from .datos import CLASE, ID, MES

def referencia(frames, cols):
    """Tasas de referencia por variable: mediana entre meses de la tasa de nulos y de ceros (robusta a un mes roto) y desvío."""
    nul = pd.concat([f[cols].isna().mean() for f in frames], axis=1).median(axis=1)
    cer = pd.concat([(f[cols] == 0).mean() for f in frames], axis=1).median(axis=1)
    sd = pd.concat([f[cols].std() for f in frames], axis=1).median(axis=1)
    return dict(nulos=nul.to_dict(), ceros=cer.to_dict(), std=sd.to_dict(), filas=float(np.median([len(f) for f in frames])))

def chequear(df, ref, spec, prev=None, imp_base=None, mes=None):
    """df: DataFrame del mes (índice = cliente). ref: salida de referencia(). prev: DataFrame del mes anterior (opcional)."""
    base = spec["base"]; faltan = [c for c in base if c not in df.columns]
    nuevas = [c for c in df.columns if c not in base and c not in (CLASE, ID, MES)]
    cols = [c for c in base if c in df.columns]
    nul, cer, sd = df[cols].isna().mean(), (df[cols] == 0).mean(), df[cols].std()
    nul_p = prev[[c for c in cols if c in prev.columns]].isna().mean() if prev is not None else None
    top = set(sorted(imp_base, key=imp_base.get, reverse=True)[:C.TOP_IMPORTANTES]) if imp_base else set()
    al, rotas = [], []
    def add(nivel, tipo, var, det):
        al.append(dict(nivel=nivel, tipo=tipo, variable=var, detalle=det, importante=var in top))
    for c in faltan: add("critica", "columna faltante", c, "no vino en el archivo: se crea con NaN"); rotas.append(c)
    for c in cols:
        rn, rc = ref["nulos"].get(c, 0), ref["ceros"].get(c, 0)
        if nul[c] >= C.Q_ROTA and rn < 0.5:
            add("critica", "mes roto (todo nulo)", c, f"{100 * nul[c]:.0f}% nulos vs {100 * rn:.0f}% de referencia"); rotas.append(c); continue
        if nul_p is not None and c in nul_p and nul[c] - nul_p[c] > C.Q_SALTO_PREV:
            add("critica", "salto de nulos vs mes anterior", c, f"{100 * nul_p[c]:.0f}% → {100 * nul[c]:.0f}%"); rotas.append(c); continue
        if cer[c] >= C.Q_ROTA and rc < 0.5:
            add("critica", "mes roto (todo ceros)", c, f"{100 * cer[c]:.0f}% ceros vs {100 * rc:.0f}% de referencia"); rotas.append(c); continue
        if (sd[c] == 0 or np.isnan(sd[c])) and ref["std"].get(c, 0) > 0 and nul[c] < C.Q_ROTA:
            add("critica", "variable constante", c, "desvío 0 (en la referencia varía)"); rotas.append(c); continue
        if nul[c] - rn > C.Q_DELTA_NULOS: add("atencion", "nulos en aumento", c, f"{100 * rn:.0f}% → {100 * nul[c]:.0f}%")
        elif cer[c] - rc > C.Q_DELTA_CEROS: add("atencion", "ceros en aumento", c, f"{100 * rc:.0f}% → {100 * cer[c]:.0f}%")
    dup = int(df.index.duplicated().sum())
    if dup: add("critica", "clientes duplicados", "numero_de_cliente", f"{dup} filas repetidas")
    if prev is not None and len(prev) and abs(len(df) / len(prev) - 1) > C.Q_DELTA_FILAS:
        add("atencion", "cambio de filas", "—", f"{len(prev):,} → {len(df):,} clientes")
    elif prev is None and abs(len(df) / max(ref["filas"], 1) - 1) > 0.5:
        add("atencion", "cambio de filas", "—", f"{len(df):,} vs ~{ref['filas']:,.0f} de referencia")
    if nuevas: add("info", "columnas nuevas", ", ".join(nuevas[:5]), f"{len(nuevas)} columnas que el modelo no conoce (se ignoran)")
    return escalar(dict(mes=mes, alertas=al, rotas=sorted(set(rotas)), faltantes=faltan, nuevas=nuevas,
                        resumen=dict(filas=int(len(df)), nulos_medio=float(nul.mean()), ceros_medio=float(cer.mean()), duplicados=dup)), imp_base)

def escalar(ch, imp_base):
    """Una alerta sobre una variable entre las más importantes del modelo sube de nivel: no pesa igual que una irrelevante."""
    top = set(sorted(imp_base, key=imp_base.get, reverse=True)[:C.TOP_IMPORTANTES]) if imp_base else set()
    for a in ch["alertas"]:
        a["importante"] = a["variable"] in top
        if a["importante"] and a["nivel"] == "atencion": a["nivel"] = "critica"
    orden = {"critica": 0, "atencion": 1, "info": 2}
    ch["alertas"] = sorted(ch["alertas"], key=lambda a: (orden[a["nivel"]], not a["importante"]))[:60]
    ch["n_critica"] = sum(a["nivel"] == "critica" for a in ch["alertas"]); ch["n_importantes"] = sum(a["importante"] for a in ch["alertas"])
    return ch

def corregir(df, ch):
    """Corrección automática: la variable rota se pone en NaN en ese mes (LightGBM sabe tratar NaN y los lags/deltas heredan el NaN).
    Devuelve la lista de acciones aplicadas. La recomendación de EXCLUIR una variable (rota varios meses seguidos) la hace produccion.py."""
    acc = []
    for v in ch["rotas"]:
        existia = v in df.columns; df[v] = np.nan
        acc.append(dict(variable=v, accion="columna creada con NaN" if not existia else "puesta en NaN este mes (no se imputa con valores inventados)"))
    return acc

def psi_ponderado(ps, imp_base):
    """PSI medio ponderado por la importancia de cada variable en el modelo (PSI 'sabio': lo que se mueve y le importa al modelo)."""
    j = [c for c in ps.index if c in imp_base]
    w = np.array([imp_base[c] for c in j]); 
    return float((w * ps[j].to_numpy()).sum() / w.sum()) if len(j) and w.sum() > 0 else float("nan")

def top_movidas(ps, imp_base, umbral=0.25):
    top = sorted(imp_base, key=imp_base.get, reverse=True)[:C.TOP_IMPORTANTES]
    return [[v, round(float(ps[v]), 3)] for v in top if v in ps.index and ps[v] > umbral]

def importancia_base(modelo):
    """Importancia (ganancia) del modelo agregada por variable cruda de origen."""
    from .variables import base_de
    g = modelo.importancias(); out = {}
    for c, v in g.items(): out[base_de(c)] = out.get(base_de(c), 0) + float(v)
    return out
