"""Artefactos que une generación y producción: modelos, columnas, perfil de referencia, parámetros y reglas."""
import datetime, json
import lightgbm as lgb
from . import io_
from .estrategias import Modelo

def guardar_modelo(art, nombre, m: Modelo):
    for i, b in enumerate(m.boosters): io_.escribir_texto(io_.unir(art, "modelos", f"{nombre}_{i}.txt"), b.model_to_string())
    io_.escribir_json(io_.unir(art, "modelos", f"{nombre}.json"), dict(cols=m.cols, nivel=m.nivel, train_hasta=m.train_hasta, meses=m.meses,
                                                                      params=m.params, rondas=m.rondas, n=len(m.boosters), id=m.id))

def cargar_modelo(art, nombre):
    j = io_.leer_json(io_.unir(art, "modelos", f"{nombre}.json"))
    bs = [lgb.Booster(model_str=io_.leer_texto(io_.unir(art, "modelos", f"{nombre}_{i}.txt"))) for i in range(j["n"])]
    return Modelo(bs, j["cols"], j["nivel"], j["train_hasta"], j["meses"], j["params"], j["rondas"], j.get("id", ""))

def ultimo_run(base):
    p = io_.unir(base, "LATEST")
    return io_.leer_texto(p).strip() if io_.existe(p) else None

def marcar_ultimo(base, run_id): io_.escribir_texto(io_.unir(base, "LATEST"), run_id)
def ahora(): return datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
