import numpy as np, pandas as pd
from sklearn.metrics import roc_auc_score, average_precision_score
from .config import C

FR_GRID = np.round(np.linspace(0, 0.15, 61), 4)    # fracción de clientes contactados

def curva_ganancia(y, p):
    o = np.argsort(-p, kind="stable")
    return np.concatenate([[0], np.cumsum(np.where(y[o] == 1, C.GANANCIA_ACIERTO, -C.COSTO_ESTIMULO))])

def ganancia_en(curva, n, frac):
    return float(curva[min(int(round(frac * n)), n)])

def metricas(y, p):
    """Métricas de un mes con clase conocida. `ganancia_opt` usa la curva suavizada (ventana ~n/300) como en la competencia 1."""
    y, p = np.asarray(y), np.asarray(p); n = len(y)
    g = curva_ganancia(y, p)
    suav = pd.Series(g).rolling(max(11, n // 300) | 1, center=True, min_periods=1).mean().to_numpy()
    k_opt = int(suav.argmax()); o = np.argsort(-p, kind="stable"); k10 = max(1, int(0.1 * n))
    sel = p > C.P_EQ
    q = np.array_split(o, 10)
    # ROC resumida en 41 puntos
    r = pd.Series(p).rank(method="first").to_numpy(); umbrales = np.quantile(p, np.linspace(0, 1, 41))
    roc = [[float((p >= u).__and__(y == 0).sum() / max((y == 0).sum(), 1)), float((p >= u).__and__(y == 1).sum() / max(y.sum(), 1))] for u in umbrales]
    return dict(n=n, n_pos=int(y.sum()), tasa=float(y.mean()), auc=float(roc_auc_score(y, p)), ap=float(average_precision_score(y, p)),
                ganancia_opt=float(suav[k_opt]), frac_opt=k_opt / n, lift10=float(y[o[:k10]].mean() / max(y.mean(), 1e-12)),
                ganancia_p025=float(np.where(y[sel] == 1, C.GANANCIA_ACIERTO, -C.COSTO_ESTIMULO).sum()), frac_p025=float(sel.mean()),
                calib=float(p.mean() / max(y.mean(), 1e-12)), p_medio=float(p.mean()),
                curva=[float(g[min(int(f * n), n)]) for f in FR_GRID], roc=roc,
                deciles_tasa=[float(y[i].mean()) for i in q], deciles_p=[float(p[i].mean()) for i in q])

def resumen_score(p):
    """Lo que se puede saber SIN la clase: forma de la distribución del score."""
    p = np.asarray(p)
    return dict(p_medio=float(p.mean()), q=[float(x) for x in np.quantile(p, [.5, .9, .95, .99])],
                frac_sobre_equilibrio=float((p > C.P_EQ).mean()))
