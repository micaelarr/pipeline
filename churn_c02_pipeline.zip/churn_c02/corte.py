"""Punto de corte. Todas las reglas usan sólo información disponible al momento de decidir."""
import numpy as np
from .config import C
from .metricas import FR_GRID, ganancia_en

def frac_previa(fracs_previas, fallback):
    """Mediana de las fracciones óptimas de meses YA etiquetados (m+GAP ≤ hoy). Sin historia: fracción implícita en p > equilibrio."""
    f = float(np.median(fracs_previas)) if len(fracs_previas) else float(fallback)
    return float(np.clip(f, FR_GRID[1], FR_GRID[-1]))        # nunca contactar a (casi) nadie ni a más del 15%

def meseta(curva_media, umbral=0.97):
    c = np.asarray(curva_media); ok = FR_GRID[c >= umbral * c.max()]
    return [float(ok.min()), float(ok.max())]

def reglas_mes(m, previas):
    """m: dict de metricas() de un mes; previas: lista de frac_opt de meses con clase ya conocida en ese momento."""
    f = frac_previa(previas, m["frac_p025"]); n = m["n"]
    return dict(R1=m["ganancia_p025"], frac_R1=m["frac_p025"], R2=float(np.interp(f, FR_GRID, m["curva"])), frac_R2=f,
                R3=m["ganancia_opt"], frac_R3=m["frac_opt"])
