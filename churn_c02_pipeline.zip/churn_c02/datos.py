"""Lectura de datos por mes. Para Google Cloud: convertir el csv a parquet particionado por foto_mes (csv_a_parquet) y leer sólo
los meses necesarios (producción lee 3 meses)."""
import os
from pathlib import Path
import numpy as np, pandas as pd
from .config import C
from . import io_

ID, MES, CLASE = "numero_de_cliente", "foto_mes", "clase_ternaria"

def mes_menos(m, k):
    t = (m // 100) * 12 + (m % 100 - 1) - k
    return (t // 12) * 100 + t % 12 + 1

def rango_meses(desde, hasta):
    out, m = [], desde
    while m <= hasta: out.append(m); m = mes_menos(m, -1)
    return out

def _a_float32(df):
    num = [c for c in df.columns if c not in (ID, MES, CLASE)]
    df[num] = df[num].astype("float32")
    return df

def leer_meses(meses, uri=None):
    """DataFrame con las filas de `meses` (float32). Parquet (archivo o carpeta) o csv/csv.gz."""
    uri, meses = str(uri or C.DATA_URI), sorted(set(int(m) for m in meses))
    if uri.endswith(".parquet") or (not io_.es_remota(uri) and os.path.isdir(uri)) or uri.rstrip("/").endswith("_pq"):
        import pyarrow.dataset as ds
        d = ds.dataset(uri, format="parquet", partitioning="hive")
        df = d.to_table(filter=ds.field(MES).isin(meses)).to_pandas()
        if MES not in df.columns: raise ValueError("el parquet debe tener foto_mes")
        df[MES] = df[MES].astype("int32")
        return _a_float32(df)
    if not io_.es_remota(uri):
        try:
            import duckdb
            lista = ",".join(map(str, meses))
            return _a_float32(duckdb.sql(f"SELECT * FROM read_csv_auto('{Path(uri).as_posix()}') WHERE {MES} IN ({lista})").df())
        except ImportError:
            pass
    partes = []
    with io_.abrir(uri, "rb") if io_.es_remota(uri) else open(uri, "rb") as f:
        for ch in pd.read_csv(f, chunksize=200_000):
            partes.append(ch[ch[MES].isin(meses)])
    return _a_float32(pd.concat(partes, ignore_index=True))

def agregar_clase(d):
    """Si no viene clase_ternaria: CONTINUA / BAJA+1 / BAJA+2 según presencia en m+1 y m+2 (NaN si m+2 no está en los datos)."""
    if CLASE in d.columns: return d
    mx = d[MES].max()
    pres = {m: set(g[ID]) for m, g in d.groupby(MES)}
    out = []
    for m, g in d.groupby(MES):
        m1, m2 = mes_menos(m, -1), mes_menos(m, -2)
        if m2 > mx or m1 not in pres or m2 not in pres:
            out.append(pd.Series(np.nan, index=g.index, dtype=object)); continue
        en1, en2 = g[ID].isin(pres[m1]), g[ID].isin(pres[m2])
        out.append(pd.Series(np.where(~en1, "BAJA+1", np.where(~en2, "BAJA+2", "CONTINUA")), index=g.index))
    d[CLASE] = pd.concat(out)
    return d

def cargar(meses, con_clase=True, uri=None):
    """dict mes -> DataFrame indexado por cliente. Con clase_ternaria (calculada si hace falta) sólo si hay meses de cola."""
    d = leer_meses(meses, uri)
    if con_clase: d = agregar_clase(d)
    return {int(m): g.set_index(ID) for m, g in d.groupby(MES)}

def csv_a_parquet(csv_uri, salida):
    """Una sola vez en la VM: csv -> parquet particionado por foto_mes (lecturas por mes en segundos)."""
    import duckdb
    os.makedirs(salida, exist_ok=True)
    duckdb.sql(f"COPY (SELECT * FROM read_csv_auto('{Path(csv_uri).as_posix()}')) TO '{Path(salida).as_posix()}' "
               f"(FORMAT PARQUET, PARTITION_BY ({MES}), OVERWRITE_OR_IGNORE)")
    return salida


# ---------------- historia: cada mes crudo que llega se agrega y queda disponible para los lags de los meses siguientes ----------------
def leer_historia(meses):
    """Meses guardados por producción en C02_HISTORIA (un csv.gz por mes)."""
    out = []
    for m in meses:
        uri = io_.unir(C.HISTORIA_DIR, f"{m}.csv.gz")
        if C.HISTORIA_DIR and io_.existe(uri):
            with io_.abrir(uri, "rb") as f: out.append(pd.read_csv(f, compression="gzip"))
    return _a_float32(pd.concat(out, ignore_index=True)) if out else None

def agregar_historia(df_crudo, mes, log=print):
    """Guarda el mes CRUDO (antes de cualquier corrección). Si el mes llega corregido, reemplaza al anterior."""
    if not C.HISTORIA_DIR: return False
    uri = io_.unir(C.HISTORIA_DIR, f"{mes}.csv.gz"); existia = io_.existe(uri)
    d = df_crudo.reset_index() if ID not in df_crudo.columns else df_crudo.copy(); d[MES] = mes
    with io_.abrir(uri, "wb") as f: d.to_csv(f, index=False, compression="gzip")
    log(f"   historia: {'reemplazado' if existia else 'agregado'} {mes} ({len(d):,} filas)")
    return True

def leer_meses_con_historia(meses, uri=None):
    """Lee de la fuente principal y completa los meses que falten con la historia agregada por producción."""
    df = leer_meses(meses, uri); faltan = [m for m in meses if m not in set(df[MES].astype(int))]
    if faltan:
        h = leer_historia(faltan)
        if h is not None: df = pd.concat([df, h], ignore_index=True)
    return df
