"""ETAPAS del pipeline de generación. Cada etapa es un proceso independiente (python3 -m churn_c02.etapas <etapa> [arg] --run <run_id>)
que lee y escribe artefactos en ART/<run_id>/etapas/. Así las estrategias se pueden lanzar EN PARALELO en la nube y, si una corrida
se corta, se reanuda desde la última etapa terminada.

  preparar ──> estrategia A | B | C | D (paralelo) ──> optuna ──> politica W ──> politica W_R | W_T (paralelo) ──> consolidar
"""
import os, sys, time, argparse, warnings
warnings.filterwarnings("ignore")
import numpy as np, pandas as pd
from .config import C, EVENTOS
from . import io_, bundle, calidad, externos
from .datos import cargar, rango_meses, mes_menos, CLASE
from .variables import Constructor, definir_spec, normalizar_fechas
from .estrategias import Almacen, ESTRATEGIAS, activas, entrenar
from .metricas import metricas, resumen_score, FR_GRID
from .deriva import Perfil, reporte, psi_scores, vista
from .optimizar import optimizar
from .monitor import alarmas, decidir
from .corte import reglas_mes, meseta

def art_dir(run_id): return io_.unir(C.ART_URI, run_id)
def _et(run_id, nombre): return io_.unir(art_dir(run_id), "etapas", nombre + ".json")
def hecho(run_id, nombre): return io_.existe(_et(run_id, nombre))
def guardar(run_id, nombre, obj): io_.escribir_json(_et(run_id, nombre), obj)
def leer(run_id, nombre): return io_.leer_json(_et(run_id, nombre))

class Ctx: pass

def _clase(fuente, mes):
    c = fuente[mes][CLASE]
    return c.notna().to_numpy(), (c == "BAJA+2").to_numpy().astype(int)

def contexto(run_id, tablas="cache", log=print):
    """Datos crudos + chequeos de calidad + correcciones + constructor de variables (+ tablas de entrenamiento desde la caché)."""
    t0 = time.time(); x = Ctx(); x.run_id, x.art = run_id, art_dir(run_id)
    ultimo = max(C.OOT_TESTS); x.meses = rango_meses(mes_menos(C.TRAIN_DESDE, 2), mes_menos(ultimo, -2))
    x.fuente = cargar(x.meses)
    x.spec = definir_spec(next(iter(x.fuente.values())).reset_index().columns)
    x.ipc = externos.cargar_ipc()
    if x.ipc: x.spec["ipc"] = externos.factores(x.ipc, C.TRAIN_HASTA, x.meses); x.spec["deriva_ipc"] = True
    for m in x.fuente: normalizar_fechas(x.fuente[m], x.spec)      # fechas de tarjeta relativas al propio mes (variables.FECHAS), ANTES de los chequeos
    train_m = [m for m in x.meses if C.TRAIN_DESDE <= m <= C.TRAIN_HASTA and m in x.fuente]
    x.ref_cal = calidad.referencia([x.fuente[m] for m in train_m], x.spec["base"])
    x.cal, prev = {}, None                      # CHEQUEOS -> CORRECCIONES, mes a mes (causal: sólo mira el mes y el anterior)
    for m in sorted(x.fuente):
        ch = calidad.chequear(x.fuente[m], x.ref_cal, x.spec, prev=prev, mes=m)
        ch["correcciones"] = calidad.corregir(x.fuente[m], ch); x.cal[m] = ch; prev = x.fuente[m]
    x.K = Constructor(x.spec, x.fuente); x.alm = Almacen(x.K); x.perfiles, x.ref_full = {}, {}
    pk = io_.unir(x.art, "cache", "almacen.pkl")
    if tablas == "cache":
        assert io_.existe(pk), "falta la etapa 'preparar' (tablas de entrenamiento)"
        d = io_.leer_pickle(pk); x.alm.tr, x.alm.ref, x.alm.cols = d["tr"], d["ref"], d["cols"]
    log(f"   contexto listo en {time.time() - t0:.0f}s ({sum(1 for c in x.cal.values() if c['rotas'])} meses con variables rotas corregidas)")
    return x

def perfil_hasta(x, th):
    if th not in x.perfiles:
        ms = [m for m in x.alm.ref if m <= th]
        p = Perfil([vista(x.alm.ref[m], x.spec, m) for m in ms]); p.ref_calidad = x.ref_cal; x.perfiles[th] = p
    return x.perfiles[th]

def evaluar(x, filas, mes, X, ok, y, variante, modelo, th, bloque, previas_base=()):
    p = modelo.predecir(X); r = metricas(y[ok], p[ok])
    if th not in x.ref_full:
        if len(x.ref_full) >= 3: x.ref_full.pop(next(iter(x.ref_full)))
        x.ref_full[th] = pd.concat([x.alm.ref[m] for m in x.alm.ref if m <= th])
    r.update(mes=mes, variante=variante, bloque=bloque, train_hasta=th, psi_score=psi_scores(modelo.predecir(x.ref_full[th]), p),
             score=resumen_score(p), max_mes_con_clase=int(max(modelo.meses)), n_modelos=len(modelo.boosters))
    previas = list(previas_base) + [f["frac_R3"] for f in filas if f["variante"] == variante and f["mes"] + C.GAP <= mes]
    r.update(reglas_mes(r, previas)); r["n_previas"] = len(previas); filas.append(r)
    return p

def _imp(modelo):
    from .variables import grupo_de
    g = modelo.importancias()
    return dict(grupos=g.groupby(g.index.map(grupo_de)).sum().round(4).to_dict(), top=g.sort_values(ascending=False).head(25).round(4).to_dict())

def _causal(spec, fuente, mes):
    a = Constructor(spec, fuente).construir(mes)
    b = Constructor(spec, {m: d for m, d in fuente.items() if m <= mes}).construir(mes)
    return bool(np.allclose(a.to_numpy("float64"), b.to_numpy("float64"), equal_nan=True))

# ------------------------------------------------------------------ etapas
def preparar(run_id, arg=None, log=print):
    t0 = time.time(); x = contexto(run_id, tablas="nueva", log=log)
    ultimo = max(C.OOT_TESTS); x.alm.preparar(rango_meses(C.TRAIN_DESDE, ultimo))
    io_.escribir_pickle(io_.unir(x.art, "cache", "almacen.pkl"), dict(tr=x.alm.tr, ref=x.alm.ref, cols=x.alm.cols))
    drift = {}
    for T in C.WF_TESTS + C.OOT_TESTS:        # chequeos sin clase y sin modelo: PSI por variable y AUC adversarial
        if T not in x.fuente: continue
        th = mes_menos(T, C.GAP) if T in C.WF_TESTS else C.TRAIN_HASTA
        drift[str(T)] = reporte(perfil_hasta(x, th), vista(x.fuente[T], x.spec, T), None, adversarial=True)
    guardar(run_id, "preparar", dict(spec=x.spec, drift=drift, calidad={str(m): c for m, c in x.cal.items() if m >= mes_menos(C.TRAIN_DESDE, 0)},
            causal=_causal(x.spec, x.fuente, C.WF_TESTS[0]), ipc=dict(activo=bool(x.ipc), extrapolados=(x.spec.get("ipc") or {}).get("_extrapolados", [])),
            tiempo=round(time.time() - t0, 1), tablas_filas=int(sum(len(v[1]) for v in x.alm.tr.values()))))

def estrategia(run_id, est, log=print):
    t0 = time.time(); x = contexto(run_id, log=log); assert est in activas(x.spec), f"{est} no está activa (¿falta el IPC?)"
    filas = []
    for T in C.WF_TESTS:                        # walk-forward 2019
        th = mes_menos(T, C.GAP); X = x.K.construir(T); ok, y = _clase(x.fuente, T)
        evaluar(x, filas, T, X, ok, y, est, entrenar(x.alm, est, th, id=est), th, "wf")
        log(f"   {est} WF {T}: AUC {filas[-1]['auc']:.3f}"); del X
    final = entrenar(x.alm, est, C.TRAIN_HASTA, id=est); bundle.guardar_modelo(x.art, est, final)
    for T in C.OOT_TESTS:                       # 2020: modelo congelado con parámetros por defecto
        if T not in x.fuente: continue
        ok, y = _clase(x.fuente, T)
        if not ok.any(): continue
        X = x.K.construir(T); evaluar(x, filas, T, X, ok, y, est, final, C.TRAIN_HASTA, "oot"); del X
        log(f"   {est} 2020 {T}: AUC {filas[-1]['auc']:.3f}")
    guardar(run_id, f"estrategia_{est}", dict(filas=filas, imp=_imp(final), tiempo=round(time.time() - t0, 1)))

def optuna_etapa(run_id, arg=None, log=print):
    t0 = time.time(); x = contexto(run_id, log=log); act = list(activas(x.spec))
    rows = [f for e in act for f in leer(run_id, f"estrategia_{e}")["filas"] if f["bloque"] == "wf"]   # selección: SÓLO 2019
    WF = pd.DataFrame(rows); S = WF.groupby("variante").agg(auc=("auc", "mean"), gan=("ganancia_opt", "mean"), auc_sd=("auc", "std"))
    S["rank"] = S.auc.rank(ascending=False) + S.gan.rank(ascending=False)
    gan = S.sort_values(["rank", "gan"], ascending=[True, False]).index[0]
    log(f"   estrategia ganadora (sólo 2019): {ESTRATEGIAS[gan]['nombre']}")
    storage = os.environ.get("C02_OPTUNA_STORAGE") or (None if io_.es_remota(C.CACHE_DIR) else f"sqlite:///{os.path.abspath(io_.unir(C.CACHE_DIR, 'optuna_' + run_id + '.db'))}")
    if storage and storage.startswith("sqlite:///"): os.makedirs(os.path.dirname(storage[10:]), exist_ok=True)
    o = optimizar(x.alm, gan, storage=storage, nombre=f"generacion_{gan}", hasta=C.TRAIN_HASTA, log=log)
    io_.escribir_csv(io_.unir(x.art, "optuna_trials.csv"), o["trials"], index=False)
    guardar(run_id, "optuna", dict(ganadora=gan, seleccion=S.round(5).reset_index().to_dict("records"), auc_ref=float(S.loc[gan, "auc"]),
            params=o["params"], rondas=o["rondas"], valor=o["valor"], valor_default=o["valor_default"], trials=int(len(o["trials"])),
            valid=C.OPTUNA_VALID, tiempo=round(time.time() - t0, 1)))

def _fracs_wf(run_id, gan):
    """Fracciones óptimas del walk-forward 2019 de la ganadora: es lo que se sabía en dic-2019 para fijar el % de contacto
    (equivale a frac_recomendada del bundle). Sin esto, los primeros meses de 2020 caían al corte p > 2,5%."""
    return [f["frac_opt"] for f in leer(run_id, f"estrategia_{gan}")["filas"] if f["bloque"] == "wf"]

def politica_W(run_id, log=print):
    t0 = time.time(); x = contexto(run_id, log=log); op = leer(run_id, "optuna"); chq = leer(run_id, "preparar"); fb = _fracs_wf(run_id, op["ganadora"])
    W = entrenar(x.alm, op["ganadora"], C.TRAIN_HASTA, op["params"], op["rondas"], id="W"); bundle.guardar_modelo(x.art, "W", W)
    imp_base = calidad.importancia_base(W)
    pf = perfil_hasta(x, C.TRAIN_HASTA); pf.fijar_score(W.predecir(pd.concat([x.alm.ref[m] for m in x.alm.ref if m <= C.TRAIN_HASTA])))
    io_.escribir_pickle(io_.unir(x.art, "perfil_referencia.pkl"), pf)
    filas, drift, alar, acc, cal, eventos, ultimo_ev = [], {}, {}, {}, {}, [], None
    for T in C.OOT_TESTS:
        if T not in x.fuente: continue
        ok, y = _clase(x.fuente, T)
        if not ok.any(): continue
        X = x.K.construir(T); p = evaluar(x, filas, T, X, ok, y, "W", W, C.TRAIN_HASTA, "oot", fb); del X
        rep = reporte(pf, vista(x.fuente[T], x.spec, T), p, adversarial=False, imp_base=imp_base)
        rep["adv"] = chq["drift"][str(T)]["adv"]; drift[str(T)] = rep
        ch = calidad.escalar(dict(chq["calidad"][str(T)]), imp_base); cal[str(T)] = ch
        al = alarmas(rep, ch)
        previo = next((f for f in filas if f["mes"] == mes_menos(T, C.GAP)), None)
        desde = 99 if ultimo_ev is None else len([t for t in C.OOT_TESTS if ultimo_ev < t <= T])
        ac = decidir(al, previo["auc"] if previo else None, op["auc_ref"], desde)
        if ac["accion"] == "reentrenar": eventos.append(T); ultimo_ev = T
        alar[str(T)], acc[str(T)] = al, ac
        log(f"   W {T}: AUC {filas[-1]['auc']:.3f} | alarma {al['nivel']} -> {ac['accion']}" + (f" | {' · '.join(m.split(' (')[0] for m in al['motivos'])}" if al["motivos"] else ""))
    guardar(run_id, "politica_W", dict(filas=filas, drift=drift, alarmas=alar, acciones=acc, calidad=cal, eventos=eventos, imp=_imp(W),
            imp_base=imp_base, tiempo=round(time.time() - t0, 1)))

def politica_W_R(run_id, log=print):
    t0 = time.time(); x = contexto(run_id, log=log); op = leer(run_id, "optuna"); filas, mR = [], None; fb = _fracs_wf(run_id, op["ganadora"])
    for T in C.OOT_TESTS:
        if T not in x.fuente: continue
        ok, y = _clase(x.fuente, T)
        if not ok.any(): continue
        thr = mes_menos(T, C.GAP); X = x.K.construir(T)
        mR = entrenar(x.alm, op["ganadora"], thr, op["params"], op["rondas"], ventana=C.VENTANA_RECAL, id="W_R")   # mismos parámetros, datos nuevos
        evaluar(x, filas, T, X, ok, y, "W_R", mR, thr, "oot", fb); del X
        log(f"   W_R {T}: AUC {filas[-1]['auc']:.3f}")
    bundle.guardar_modelo(x.art, "W_R_ultimo", mR)
    guardar(run_id, "politica_W_R", dict(filas=filas, imp=_imp(mR), tiempo=round(time.time() - t0, 1)))

def politica_W_T(run_id, log=print):
    t0 = time.time(); x = contexto(run_id, log=log); op = leer(run_id, "optuna"); ev = leer(run_id, "politica_W")["eventos"]
    modelo, filas, reentrenos = bundle.cargar_modelo(x.art, "W"), [], []; modelo.id = "W_T"; fb = _fracs_wf(run_id, op["ganadora"])
    for T in C.OOT_TESTS:
        if T not in x.fuente: continue
        ok, y = _clase(x.fuente, T)
        if not ok.any(): continue
        thr = mes_menos(T, C.GAP)
        if T in ev:                            # REENTRENAR = volver a correr la generación (con Optuna) con datos hasta T-GAP
            log(f"   {T}: el monitor pide REENTRENAR -> Optuna ({C.REENTRENAR_TRIALS} trials)")
            o2 = optimizar(x.alm, op["ganadora"], n_trials=C.REENTRENAR_TRIALS, storage=None, nombre=f"reentreno_{T}",
                           valid_meses=[thr, mes_menos(thr, 1)], hasta=thr, log=log,
                           inicial=(op["params"], op["rondas"]))      # parte de los hiperparámetros vigentes, no del default
            modelo = entrenar(x.alm, op["ganadora"], thr, o2["params"], o2["rondas"], ventana=C.VENTANA_RECAL, id="W_T")
            reentrenos.append(dict(mes=T, params=o2["params"], rondas=o2["rondas"], valor=o2["valor"]))
        X = x.K.construir(T); evaluar(x, filas, T, X, ok, y, "W_T", modelo, modelo.train_hasta, "oot", fb); del X
        log(f"   W_T {T}: AUC {filas[-1]['auc']:.3f}")
    guardar(run_id, "politica_W_T", dict(filas=filas, reentrenos=reentrenos, imp=_imp(modelo), tiempo=round(time.time() - t0, 1)))

def consolidar(run_id, arg=None, log=print):
    pre, op, w = leer(run_id, "preparar"), leer(run_id, "optuna"), leer(run_id, "politica_W")
    wr, wt = leer(run_id, "politica_W_R"), leer(run_id, "politica_W_T")
    ests = [e for e in ESTRATEGIAS if hecho(run_id, f"estrategia_{e}")]
    est_r = {e: leer(run_id, f"estrategia_{e}") for e in ests}
    filas = [f for e in ests for f in est_r[e]["filas"]] + w["filas"] + wr["filas"] + wt["filas"]
    gan, art = op["ganadora"], art_dir(run_id)
    wf_g = [f for f in est_r[gan]["filas"] if f["bloque"] == "wf"]
    curva_media = np.mean(np.array([f["curva"] for f in wf_g]), axis=0)
    frac_rec = float(np.median([f["frac_opt"] for f in wf_g]))
    viol = sum(1 for f in filas if f["max_mes_con_clase"] + C.GAP > f["mes"])
    tiempos = {"preparar": pre["tiempo"], **{f"estrategia {e}": est_r[e]["tiempo"] for e in ests}, "optuna": op["tiempo"],
               "política W": w["tiempo"], "política W_R": wr["tiempo"], "política W_T": wt["tiempo"]}
    nombres = {e: ESTRATEGIAS[e]["nombre"] for e in ests}
    nombres.update(W=f"W · {gan} con Optuna (congelado)", W_R=f"W_R · {gan} recalibrado cada mes (mismos parámetros, datos nuevos)",
                   W_T=f"W_T · {gan} reentrenado con Optuna cuando el monitor lo pide")
    drift = {**{k: v for k, v in pre["drift"].items() if int(k) in C.WF_TESTS}, **w["drift"]}
    cal_wf = {k: v for k, v in pre["calidad"].items() if int(k) in C.WF_TESTS}
    aud = [dict(chequeo="Variables causales: las variables de un mes no cambian si se borran los meses posteriores", ok=pre["causal"], detalle=f"verificado sobre {C.WF_TESTS[0]}"),
           dict(chequeo="La estrategia ganadora se eligió usando sólo 2019 (2020 es la prueba fuera de tiempo)", ok=True, detalle=f"ganadora {gan}; meses {C.WF_TESTS}"),
           dict(chequeo="Optuna valida con gap, con meses de 2019, y 201912 (test de estrategias) nunca entra a la BO", ok=all(v <= C.TRAIN_HASTA for v in C.OPTUNA_VALID) and 201912 not in C.OPTUNA_VALID, detalle=f"validación {C.OPTUNA_VALID}"),
           dict(chequeo="Ningún modelo vio una clase que en el mes evaluado todavía no se conocía (la clase de T se conoce en T+2)", ok=viol == 0, detalle=f"violaciones: {viol}"),
           dict(chequeo="Chequeos de calidad y correcciones: mismas funciones en generación y producción; la detección de meses rotos es causal (mes vs. mes anterior y vs. referencia)", ok=True, detalle="calidad.py"),
           dict(chequeo="El perfil de deriva y su referencia de calidad se construyen sólo con meses ≤ fin del entrenamiento", ok=True, detalle=f"≤ {C.TRAIN_HASTA}"),
           dict(chequeo="El corte por % usa sólo meses ya etiquetados (en 2020 arranca con las fracciones óptimas del walk-forward 2019)", ok=True, detalle="mediana de frac. óptima de meses con m+2 ≤ hoy"),
           dict(chequeo="Fechas de tarjeta relativas a la moda del mes y deriva medida en pesos constantes (si hay IPC), sin variables de tendencia", ok=bool(pre["spec"].get("fechas") is not None), detalle=f"fechas normalizadas: {len(pre['spec'].get('fechas') or [])}"),
           dict(chequeo="Percentiles dentro del mes: corte transversal del propio mes (disponible al puntuar); IPC: sólo niveles ya publicados (o extrapolados y avisados)", ok=True, detalle=f"IPC activo: {pre['ipc']['activo']}"),
           dict(chequeo="Capa de LLM: sólo recibe métricas agregadas 'a la fecha' y nunca la clase de meses aún no etiquetados", ok=True, detalle="ver narrador.py")]
    manifest = dict(run_id=run_id, creado=bundle.ahora(), train=[C.TRAIN_DESDE, C.TRAIN_HASTA], ganadora=gan, auc_referencia=op["auc_ref"], params=op["params"],
                    rondas=op["rondas"], optuna=dict(valor=op["valor"], valor_default=op["valor_default"], trials=op["trials"]), frac_recomendada=frac_rec,
                    meseta=meseta(curva_media), spec=pre["spec"], ventana_recal=C.VENTANA_RECAL, imp_base=w["imp_base"],
                    estrategias=ests, umbrales=dict(psi_score=C.ALARMA_PSI_SCORE, psi_pond=C.ALARMA_PSI_POND, top_movidas=C.ALARMA_TOP_MOVIDAS, adv=C.ALARMA_ADV),
                    tiempos=tiempos, ganancia=[C.GANANCIA_ACIERTO, C.COSTO_ESTIMULO])
    io_.escribir_json(io_.unir(art, "manifest.json"), manifest)
    imp = {**{e: est_r[e]["imp"] for e in ests}, "W": w["imp"], "W_R": wr["imp"], "W_T": wt["imp"]}
    bt = dict(manifest=manifest, nombres=nombres, resultados=filas, drift=drift, alarmas=w["alarmas"], acciones=w["acciones"], reentrenos=wt["reentrenos"],
              importancias=imp, auditoria=aud, seleccion_wf=op["seleccion"], eventos={str(k): v for k, v in EVENTOS.items()},
              curva_wf_media=[float(c) for c in curva_media], fr_grid=[float(f) for f in FR_GRID], tiempos=tiempos, pandemia=list(C.PANDEMIA),
              calidad={**cal_wf, **w["calidad"]}, ipc=pre["ipc"])
    io_.escribir_json(io_.unir(art, "backtest.json"), bt)
    bundle.marcar_ultimo(C.ART_URI, run_id)
    from . import dashboard
    dashboard.generar(art, log=log)
    guardar(run_id, "consolidar", dict(ok=True))

EJECUTAR = {"preparar": preparar, "estrategia": estrategia, "optuna": optuna_etapa, "politica": None, "consolidar": consolidar}

def ejecutar(nombre, arg, run_id, log=print):
    log(f"=== etapa {nombre}{'_' + arg if arg else ''} | run {run_id}")
    if nombre == "politica": {"W": politica_W, "W_R": politica_W_R, "W_T": politica_W_T}[arg](run_id, log=log)
    elif nombre == "estrategia": estrategia(run_id, arg, log=log)
    else: EJECUTAR[nombre](run_id, arg, log=log)

if __name__ == "__main__":
    ap = argparse.ArgumentParser(); ap.add_argument("etapa"); ap.add_argument("arg", nargs="?"); ap.add_argument("--run", default=C.RUN)
    a = ap.parse_args(); assert a.run, "indicá --run <run_id> (o C02_RUN)"
    ejecutar(a.etapa, a.arg, a.run)
