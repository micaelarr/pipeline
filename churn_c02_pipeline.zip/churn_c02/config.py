"""Configuración central. Todo se puede pisar con variables de entorno C02_* (útil en Google Cloud)."""
import os
from types import SimpleNamespace

def _e(nombre, defecto, tipo=str):
    v = os.environ.get(nombre)
    return defecto if v is None else tipo(v)

def _lista(nombre, defecto):
    v = os.environ.get(nombre)
    return defecto if v is None else [int(x) for x in v.split(",") if x]

C = SimpleNamespace(
    # --- Rutas (local o gs://bucket/...) ---
    DATA_URI=_e("C02_DATA", "competencia_02.csv"),            # csv, parquet o carpeta parquet particionada por foto_mes
    ART_URI=_e("C02_ARTEFACTOS", "artefactos"),                # acá se guardan bundle, backtest, dashboard, scores
    CACHE_DIR=_e("C02_CACHE", "cache"),
    # --- Ventana temporal ---
    TRAIN_DESDE=_e("C02_TRAIN_DESDE", 201901, int), TRAIN_HASTA=_e("C02_TRAIN_HASTA", 201912, int),
    WF_TESTS=_lista("C02_WF_TESTS", [201906, 201908, 201910, 201912]),   # walk-forward en 2019
    OOT_TESTS=_lista("C02_OOT_TESTS", [202001, 202002, 202003, 202004, 202005, 202006, 202007, 202008, 202009, 202010, 202011, 202012]),
    PANDEMIA=(202007, 202008, 202009),
    GAP=2,                                                      # la clase de un mes se conoce 2 meses después
    # --- Negocio ---
    GANANCIA_ACIERTO=1_072_500, COSTO_ESTIMULO=27_500,
    # --- Modelo ---
    FRAC_CONT_GUARDADA=0.30, FRAC_CONT_ENTRENO=0.10,
    LGB_DEFAULT=dict(objective="binary", learning_rate=0.05, num_leaves=31, min_data_in_leaf=100, feature_fraction=0.3,
                     bagging_fraction=0.8, bagging_freq=1, lambda_l2=1.0, verbosity=-1),
    N_RONDAS_DEFAULT=250, DECAY=0.85, SEMILLAS_C=[101, 202, 303], NUM_HILOS=_e("C02_HILOS", os.cpu_count() or 1, int),
    # --- Optuna (pipeline de generación) ---
    OPTUNA_TRIALS=_e("C02_OPTUNA_TRIALS", 40, int), OPTUNA_TIMEOUT_S=_e("C02_OPTUNA_TIMEOUT_S", 0, int) or None,
    OPTUNA_VALID=_lista("C02_OPTUNA_VALID", [201909, 201911]),  # meses de validación de la BO (con train ≤ mes-GAP). 201912 queda sin ver: es el test de estrategias
    OPTUNA_METRICA=_e("C02_OPTUNA_METRICA", "auc"),             # auc | ganancia
    REENTRENAR_TRIALS=_e("C02_REENTRENAR_TRIALS", 10, int),
    # --- Recalibración / monitoreo ---
    VENTANA_RECAL=_e("C02_VENTANA_RECAL", 12, int),             # meses con clase conocida que entran a una recalibración
    ALARMA_PSI_SCORE=0.25, ALARMA_ADV=0.80, ALARMA_CALIB=(0.5, 2.0),
    ALARMA_ADV_ACTIVA=_e("C02_ALARMA_ADV", 0, int) == 1,  # gen2: el AUC adversarial dio 0,97-0,99 en los meses de 2019 (donde el modelo
                                                        # anda bien): no discrimina, queda como dato informativo y no dispara alarmas
    ALARMA_PSI_POND=0.10,          # PSI de las variables ponderado por su importancia en el modelo
    ALARMA_TOP_MOVIDAS=3,          # cuántas de las variables más importantes pueden tener PSI > 0,25 antes de alarmar
    TOP_IMPORTANTES=15, ALARMA_FRAC_VARS=0.15,                  # (frac_vars sólo informativa: PSI "a ciegas" no dispara alarmas)
    # --- Chequeos de calidad de datos ---
    Q_DELTA_NULOS=0.30, Q_DELTA_CEROS=0.30, Q_ROTA=0.99, Q_DELTA_FILAS=0.30, Q_SALTO_PREV=0.50,
    # --- Datos externos / historia / salidas ---
    IPC_URI=_e("C02_IPC", ""),                                  # csv con columnas foto_mes, ipc (nivel general, cualquier base)
    HISTORIA_DIR=_e("C02_HISTORIA", ""),                        # carpeta donde producción agrega cada mes crudo que llega
    CORTES_MULT=[0.8, 1.0, 1.2],                                # cortes alternativos que se exportan (múltiplos del corte recomendado)
    RUN=_e("C02_RUN", ""),
    PARALELO_MAX=_e("C02_PARALELO_MAX", 4, int),                # procesos en paralelo (bajar a 2 si falta memoria RAM)
    MIN_MESES_ENTRE_REENTRENOS=3,
    LIMITE_SCORING_S=15 * 60,
    # --- LLM opcional (sólo capa narrativa; ver narrador.py para el control de leak) ---
    LLM=_e("C02_LLM", "none"), LLM_MODEL=_e("C02_LLM_MODEL", "claude-sonnet-5-5"),
)
C.P_EQ = C.COSTO_ESTIMULO / (C.GANANCIA_ACIERTO + C.COSTO_ESTIMULO)

# Contexto externo (NO entra al modelo; sólo se muestra en el dashboard para contar la historia)
EVENTOS = {
    202003: "Argentina decreta el aislamiento obligatorio (ASPO, 20/03)",
    202004: "Cuarentena estricta: se frena la actividad y la presencialidad bancaria",
    202007: "Ventana de interés: pandemia en pleno desarrollo",
    202011: "Pasa de ASPO a DISPO (distanciamiento): apertura gradual",
}
