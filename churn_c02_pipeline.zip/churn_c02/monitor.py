"""Alarmas SIN clase (drift, score) y política de decisión: score / recalibrar / reentrenar.

  score       = usar el modelo congelado tal cual.
  recalibrar  = MISMOS hiperparámetros y estrategia, cambia el input: se vuelve a ajustar con una ventana de datos actualizada.
  reentrenar  = volver a correr el pipeline de generación (incluye Optuna): puede cambiar los hiperparámetros.
"""
from .config import C

def alarmas(rep, calidad=None, calib=None):
    """rep: salida de deriva.reporte (con imp_base). calidad: chequeo del mes (calidad.chequear). El PSI se usa con criterio:
    ponderado por importancia y mirando las variables top; el % de variables movidas es sólo informativo."""
    mot = []
    if rep.get("psi_score") is not None and rep["psi_score"] > C.ALARMA_PSI_SCORE: mot.append(f"PSI del score {rep['psi_score']:.2f} > {C.ALARMA_PSI_SCORE}")
    if rep.get("psi_pond") is not None and rep["psi_pond"] > C.ALARMA_PSI_POND: mot.append(f"PSI ponderado por importancia {rep['psi_pond']:.2f} > {C.ALARMA_PSI_POND}")
    if rep.get("n_top_movidas", 0) >= C.ALARMA_TOP_MOVIDAS:
        mot.append(f"{rep['n_top_movidas']} de las {C.TOP_IMPORTANTES} variables más importantes con PSI > 0,25 ({', '.join(v for v, _ in rep['top_movidas'][:3])}…)")
    if C.ALARMA_ADV_ACTIVA and rep.get("adv") is not None and rep["adv"] > C.ALARMA_ADV: mot.append(f"AUC adversarial {rep['adv']:.2f} > {C.ALARMA_ADV}")
    if calidad is not None and calidad.get("n_importantes", 0) and calidad.get("n_critica", 0):
        imp = [a["variable"] for a in calidad["alertas"] if a["importante"] and a["nivel"] == "critica"]
        if imp: mot.append(f"calidad de datos: variable(s) importante(s) con problemas críticos ({', '.join(imp[:3])})")
    if calib is not None and not (C.ALARMA_CALIB[0] <= calib <= C.ALARMA_CALIB[1]): mot.append(f"calibración {calib:.2f} fuera de {C.ALARMA_CALIB}")
    return dict(nivel=0 if not mot else (1 if len(mot) == 1 else 2), motivos=mot)

def decidir(alarma, auc_realizado=None, auc_referencia=None, meses_desde_reentreno=99):
    """Regla de decisión. El rendimiento realizado de T llega con 2 meses de atraso (la clase de T se conoce en T+2)."""
    caida = None if auc_realizado is None or auc_referencia is None else auc_referencia - auc_realizado
    if alarma["nivel"] == 0: return dict(accion="score", por_que="Sin alarmas de deriva: el modelo congelado sigue siendo válido.", caida_auc=caida)
    if alarma["nivel"] >= 2 and caida is not None and caida > 0.03 and meses_desde_reentreno >= C.MIN_MESES_ENTRE_REENTRENOS:
        return dict(accion="reentrenar", por_que=f"Alarma doble y el AUC realizado cayó {caida:.3f}: recalibrar no alcanza, hay que volver a correr la generación (Optuna).", caida_auc=caida)
    return dict(accion="recalibrar", por_que="Hay deriva: se mantienen hiperparámetros y estrategia y se reajusta el modelo con datos recientes.", caida_auc=caida)
