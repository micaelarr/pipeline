"""Historia en lenguaje humano, mes a mes. Dos bloques con distinto 'momento de conocimiento':
  VIVO        = lo que se veía en el mes T, sin clase (deriva, forma del score, alarmas).
  POST-MORTEM = lo que se supo recién en T+2 (AUC y ganancia realizados).
Control de leak del LLM (opcional, C02_LLM=anthropic): sólo recibe un payload armado por payload_vivo / payload_postmortem.
El de 'vivo' no contiene NINGUNA métrica realizada; el de post-mortem sólo se arma si mes + GAP <= as_of.
El LLM nunca recibe filas de clientes, ni genera variables, ni toca el score: sólo redacta."""
import json, os
import numpy as np
from .config import C

def nombre_humano(v):
    base = v
    pref = {"Visa_": "tarjeta Visa · ", "Master_": "tarjeta Master · ", "pct_": "posición relativa de ", "pctdelta1_": "cambio de posición relativa de ",
            "pctlag1_": "posición relativa (mes anterior) de "}
    p = ""
    for k, t in pref.items():
        if base.startswith(k): p, base = t, base[len(k):]; break
    suf = {"_lag1": " (mes anterior)", "_lag2": " (hace 2 meses)", "_delta1": " (variación vs mes anterior)", "_delta2": " (variación vs hace 2 meses)",
           "_ratiolag1": " (relación con mes anterior)", "_ratioavg3": " (relación con su promedio 3m)", "_avg3": " (promedio 3m)", "_max3": " (máx. 3m)",
           "_min3": " (mín. 3m)", "_ratiomax3": " (relación con su máx. 3m)"}
    s = ""
    for k, t in suf.items():
        if base.endswith(k): base, s = base[:-len(k)], t; break
    return p + base.replace("_", " ") + s

def _adj_adv(a):
    if a is None: return "sin dato"
    return "casi indistinguibles" if a < .6 else "algo distintos" if a < .7 else "claramente distintos" if a < .85 else "radicalmente distintos"

def _adj_psi(p):
    return "estable" if p is None or p < .1 else "con corrimiento moderado" if p < .25 else "con corrimiento fuerte"

def payload_vivo(m):
    """Sólo información disponible en el mes T (sin clase)."""
    d = m["drift"]
    return dict(mes=m["mes"], evento=m.get("evento"), variables_movidas=d["n_psi25"], total_variables=d["n_vars"], psi_medio=d["psi_medio"],
                adversarial=d.get("adv"), psi_score=d.get("psi_score"), psi_ponderado=d.get("psi_pond"), variables_rotas=(m.get("calidad") or {}).get("rotas", []), top_variables=[(k, v) for k, v in d["top"][:5]],
                alarma=m["alarma"], accion=m["accion"]["accion"], score=m["v"].get("W", {}).get("score"))

def payload_postmortem(m, as_of):
    if m["mes"] + C.GAP > as_of: return None                      # la clase de T todavía no se conoce
    r = {k: {x: v[x] for x in ("auc", "ap", "ganancia_opt", "frac_opt", "lift10", "calib", "ganancia_p025", "frac_p025", "R2", "frac_R2")} for k, v in m["v"].items()}
    return dict(mes=m["mes"], variantes=r)

def historia_vivo(m):
    d, a = m["drift"], m["alarma"]
    top = ", ".join(f"{nombre_humano(k)} (PSI {v:.2f})" for k, v in d["top"][:3]) or "—"
    partes = []
    if m.get("evento"): partes.append(f"Contexto: {m['evento']}.")
    partes.append(f"Se movieron {d['n_psi25']} de {d['n_vars']} variables de forma fuerte (PSI>0,25); las que más: {top}.")
    if d.get("adv") is not None: partes.append(f"Un modelo que intenta distinguir este mes de 2019 acierta con AUC {d['adv']:.2f}: los clientes se ven {_adj_adv(d['adv'])} a los que el modelo aprendió" + ("." if C.ALARMA_ADV_ACTIVA else " (dato informativo: en los meses de 2019 ya daba valores parecidos, por eso no dispara alarmas)."))
    if d.get("psi_pond") is not None: partes.append(f"Ponderando el PSI por la importancia de cada variable en el modelo da {d['psi_pond']:.2f}; {d.get('n_top_movidas', 0)} de las {C.TOP_IMPORTANTES} variables más importantes se movieron fuerte.")
    if d.get("psi_score") is not None: partes.append(f"La forma del score está {_adj_psi(d['psi_score'])} (PSI {d['psi_score']:.2f}).")
    cal = m.get("calidad") or {}
    if cal.get("rotas"): partes.append("Chequeo de datos: " + ", ".join(cal["rotas"][:3]) + " llegó rota (" + "; ".join(sorted({a["tipo"] for a in cal["alertas"] if a["variable"] in cal["rotas"]})[:2]) + ") y se corrigió poniéndola en NaN para ese mes.")
    elif cal.get("n_alertas"): partes.append(f"Chequeo de datos: {cal['n_alertas']} alerta(s) menores, sin variables rotas.")
    acc = m["accion"]["accion"]
    partes.append({"score": "Ninguna alarma: se puntúa con el modelo congelado.", "recalibrar": "Alarma: conviene RECALIBRAR (mismos parámetros, datos nuevos). " + "; ".join(a["motivos"]) + ".",
                   "reentrenar": "Alarma crítica: conviene REENTRENAR (volver a correr la generación con Optuna). " + "; ".join(a["motivos"]) + "."}[acc])
    return " ".join(partes)

def historia_post(m, as_of):
    if m["mes"] + C.GAP > as_of: return "La clase de este mes todavía no se conoce (llega 2 meses después): no hay veredicto de rendimiento."
    v = m["v"]; W = v.get("W") or v.get("C") or next(iter(v.values())); A = v.get("A")
    txt = [f"Con la clase ya conocida: AUC {W['auc']:.3f}" + (f" contra {A['auc']:.3f} del baseline A ({W['auc'] - A['auc']:+.3f})." if A and W is not A else ".")]
    txt.append(f"Cortando en p>2,5% se habría contactado el {100 * W['frac_p025']:.1f}% de los clientes y ganado {W['R1'] / 1e6:.1f} M; con un % fijo ({100 * W['frac_R2']:.1f}%), {W['R2'] / 1e6:.1f} M; el techo (óptimo conocido a posteriori) era {W['R3'] / 1e6:.1f} M al {100 * W['frac_R3']:.1f}%.")
    if "W_R" in v and "W" in v: txt.append(f"Recalibrar cada mes habría dado AUC {v['W_R']['auc']:.3f} ({v['W_R']['auc'] - v['W']['auc']:+.3f}) y {v['W_R']['ganancia_opt'] / 1e6:.1f} M ({(v['W_R']['ganancia_opt'] - v['W']['ganancia_opt']) / 1e6:+.1f} M).")
    if "W_T" in v and "W" in v and abs(v["W_T"]["auc"] - v["W"]["auc"]) > 1e-9: txt.append(f"Con el reentrenamiento: AUC {v['W_T']['auc']:.3f}.")
    c = W["calib"]; txt.append(f"Calibración (prob. media / tasa real): {c:.2f} " + ("(el modelo sobrestima las bajas)." if c > 1.3 else "(el modelo subestima las bajas)." if c < .75 else "(razonable)."))
    return " ".join(txt)

# ---------------- LLM opcional ----------------
def _llm(sistema, payload, texto_base):
    if C.LLM != "anthropic" or not os.environ.get("ANTHROPIC_API_KEY"): return texto_base
    try:
        import anthropic
        r = anthropic.Anthropic().messages.create(model=C.LLM_MODEL, max_tokens=400, system=sistema,
            messages=[{"role": "user", "content": "Datos (JSON):\n" + json.dumps(payload, ensure_ascii=False, default=float) + "\n\nBorrador:\n" + texto_base}])
        return r.content[0].text.strip()
    except Exception:
        return texto_base

SIS = ("Redactás para un tablero de monitoreo de un modelo de churn bancario. Reescribí el borrador en español rioplatense claro, 3-4 oraciones, "
       "sin inventar números ni causas que no estén en los datos. No uses información que no esté en el JSON.")

def redactar(m, as_of):
    """Devuelve {vivo, postmortem} para un mes. as_of = último mes con datos disponibles (para el control de leak)."""
    vivo = _llm(SIS + " Es lo que se veía ese mes SIN conocer la clase.", payload_vivo(m), historia_vivo(m))
    pm = payload_postmortem(m, as_of)
    post = historia_post(m, as_of) if pm is None else _llm(SIS + " Es el post-mortem, 2 meses después, con la clase conocida.", pm, historia_post(m, as_of))
    return dict(vivo=vivo, postmortem=post)

# ---------------- capítulos ----------------
def _prom(meses, f):
    xs = [f(m) for m in meses]; xs = [x for x in xs if x is not None and not np.isnan(x)]
    return float(np.mean(xs)) if xs else float("nan")

def capitulos(meses_oot, wf, pandemia):
    """meses_*: listas de dicts de mes. Devuelve los capítulos de la historia con números reales."""
    A = lambda m, k, v="W": (m["v"].get(v) or {}).get(k)
    caps = []
    wf_auc = {v: _prom(wf, lambda m, v=v: A(m, "auc", v)) for v in ("A", "B", "C")}
    caps.append(dict(titulo="1 · 2019: el mundo que el modelo aprendió", meses=[m["mes"] for m in wf],
                     texto=f"En el walk-forward de 2019 (se reentrena cada vez con la clase conocida hasta 2 meses antes) el AUC promedio fue {wf_auc['A']:.3f} para el baseline A, "
                           f"{wf_auc['B']:.3f} con historia (B) y {wf_auc['C']:.3f} con la versión robusta (C). La estrategia ganadora se eligió mirando SÓLO estos meses: 2020 quedó como prueba ciega."))
    def periodo(titulo, ms, extra=""):
        if not ms: return
        aW, aA, aR, aT = (_prom(ms, lambda m, v=v: A(m, "auc", v)) for v in ("W", "A", "W_R", "W_T"))
        gW, gR = _prom(ms, lambda m: A(m, "ganancia_opt", "W")), _prom(ms, lambda m: A(m, "ganancia_opt", "W_R"))
        psi = _prom(ms, lambda m: m["drift"]["n_psi25"]); alar = [m["mes"] for m in ms if m["alarma"]["nivel"] > 0]
        t = (f"El modelo congelado en 201912 rinde AUC {aW:.3f} (baseline A {aA:.3f}). En promedio {psi:.0f} variables se movieron de forma fuerte. "
             f"Recalibrar cada mes daría AUC {aR:.3f} y {gR / 1e6:.1f} M de ganancia óptima media contra {gW / 1e6:.1f} M del congelado. "
             + (f"El monitor encendió alarmas en {', '.join(str(a) for a in alar)}." if alar else "El monitor no encendió alarmas.") + " " + extra)
        caps.append(dict(titulo=titulo, meses=[m["mes"] for m in ms], texto=t.strip()))
    periodo("2 · Enero–febrero de 2020: la calma previa", [m for m in meses_oot if 202001 <= m["mes"] <= 202002])
    periodo("3 · Marzo–junio: el shock", [m for m in meses_oot if 202003 <= m["mes"] <= 202006], "Es el período en el que más cambia el comportamiento de los clientes.")
    periodo("4 · Julio–septiembre: la ventana de interés", [m for m in meses_oot if m["mes"] in pandemia], "Meses pedidos para evaluar cómo funciona el modelo en plena pandemia.")
    periodo("5 · Octubre–diciembre: ¿vuelve la normalidad?", [m for m in meses_oot if m["mes"] >= 202010])
    return caps
