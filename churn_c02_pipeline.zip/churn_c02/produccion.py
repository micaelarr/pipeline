"""PIPELINE DE PRODUCCIÓN (rápido: lectura de 3 meses + chequeos + variables + predicción; objetivo < 15 min).
  Input -> Feature engineering -> Chequeos (calidad + drift) -> Alertas (dashboard) -> Correcciones -> N estrategias -> salidas
Modos:
  score       -> modelos congelados del bundle (por defecto)
  recalibrar  -> mismos hiperparámetros y estrategia, se reajusta con una ventana de datos recientes (no corre Optuna)
Reentrenar = volver a correr la generación (python3 run_generacion.py). `cerrar(mes)` completa las métricas reales cuando llega la clase."""
import json, time
import numpy as np, pandas as pd
from .config import C
from . import io_, bundle, calidad, externos
from .datos import (rango_meses, mes_menos, agregar_clase, leer_meses_con_historia, leer_meses, agregar_historia, CLASE, ID, MES)
from .variables import Constructor, normalizar_fechas
from .estrategias import Almacen, entrenar
from .metricas import metricas, resumen_score
from .deriva import reporte, vista
from .monitor import alarmas, decidir
from .corte import frac_previa, reglas_mes

def _historial(art):
    uri = io_.unir(art, "produccion", "historial.jsonl")
    return [json.loads(l) for l in io_.leer_texto(uri).splitlines() if l.strip()] if io_.existe(uri) else []

def _guardar_historial(art, h):
    io_.escribir_texto(io_.unir(art, "produccion", "historial.jsonl"), "\n".join(json.dumps(x, ensure_ascii=False, default=float) for x in h) + "\n")

def _indexar(df): return {int(m): g.set_index(ID) for m, g in df.groupby(MES)}

def run(mes, modo="score", run_id=None, uri_mes_nuevo=None, evaluar=False, log=print, dashboard=True):
    t0 = time.time(); tiempos = {}
    def marca(n): tiempos[n] = round(time.time() - t0, 1); log(f"[{tiempos[n]:>6.1f}s] {n}")
    run_id = run_id or bundle.ultimo_run(C.ART_URI); assert run_id, "no hay corrida de generación: corré generacion.run() primero"
    art = io_.unir(C.ART_URI, run_id); man = io_.leer_json(io_.unir(art, "manifest.json")); spec = man["spec"]; imp_base = man["imp_base"]
    perfil = io_.leer_pickle(io_.unir(art, "perfil_referencia.pkl"))
    modelos = {e: bundle.cargar_modelo(art, e) for e in man["estrategias"] + ["W"] if e != "D" or spec.get("ipc")}; marca("bundle cargado")
    assert mes > man["train"][1], f"{mes} cae dentro del entrenamiento (≤ {man['train'][1]}): sería leak"

    # ---- INPUT: el mes nuevo (crudo) + 2 meses de historia (o la ventana de recalibración)
    if modo == "recalibrar": meses = rango_meses(mes_menos(mes, C.GAP + man["ventana_recal"] + 2), mes)
    else: meses = [mes_menos(mes, 2), mes_menos(mes, 1), mes]
    if evaluar: meses = meses + [mes_menos(mes, -1), mes_menos(mes, -2)]
    conclase = modo == "recalibrar" or evaluar
    df = leer_meses_con_historia([m for m in meses if m != mes] if uri_mes_nuevo else meses)
    if uri_mes_nuevo: df = pd.concat([df, leer_meses([mes], uri_mes_nuevo)], ignore_index=True)
    if conclase: df = agregar_clase(df)
    fuente = _indexar(df); assert mes in fuente, f"el mes {mes} no está en los datos"
    historia_ok = all(mes_menos(mes, k) in fuente for k in (1, 2))
    if uri_mes_nuevo: agregar_historia(fuente[mes].copy(), mes, log)          # el mes crudo queda guardado para los próximos lags
    marca("lectura")

    # ---- IPC (datos externos): se refresca con el archivo si existe; si falta el mes, se extrapola y se avisa
    ipc = externos.cargar_ipc()
    if ipc: spec["ipc"] = externos.factores(ipc, man["train"][1], sorted(set(meses) | {mes}))
    ipc_ok = bool(spec.get("ipc")) and str(mes) in spec["ipc"]
    # ---- CHEQUEOS -> CORRECCIONES (mismas funciones que la generación)
    for m in fuente: normalizar_fechas(fuente[m], spec)          # igual que en generación: fechas relativas al mes, antes de los chequeos
    prev, ch_mes = None, None
    for m in sorted(m for m in fuente if m <= mes):
        ch = calidad.chequear(fuente[m], perfil.ref_calidad, spec, prev=prev, imp_base=imp_base, mes=m)
        ch["correcciones"] = calidad.corregir(fuente[m], ch); prev = fuente[m]
        if m == mes: ch_mes = ch
    hist = _historial(art); top_imp = set(sorted(imp_base, key=imp_base.get, reverse=True)[:C.TOP_IMPORTANTES])
    for v in ch_mes["rotas"]:     # una variable rota varios meses seguidos: recomendar excluirla
        n = sum(1 for h in hist[-3:] if v in (h.get("calidad") or {}).get("rotas", []))
        if n >= 2: ch_mes["alertas"].insert(0, dict(nivel="critica", tipo="variable rota varios meses", variable=v, importante=v in top_imp,
                                                    detalle=f"rota en {n + 1} de los últimos 3 meses: conviene EXCLUIRLA del modelo y recalibrar sin ella"))
    if spec.get("ipc") and not ipc_ok:
        ch_mes["alertas"].insert(0, dict(nivel="atencion", tipo="IPC no disponible", variable="ipc", importante=False, detalle=f"sin IPC para {mes}: la estrategia D usa NaN en las variables reales"))
    marca("chequeos y correcciones")
    K = Constructor(spec, fuente); X = K.construir(mes); n = len(X); marca("variables")

    # ---- N estrategias
    if modo == "recalibrar":
        alm = Almacen(K); alm.preparar(rango_meses(mes_menos(mes, C.GAP + man["ventana_recal"] + 1), mes_menos(mes, C.GAP)))
        modelos["W_R"] = entrenar(alm, man["ganadora"], mes_menos(mes, C.GAP), man["params"], man["rondas"], ventana=man["ventana_recal"], id="W_R")
        bundle.guardar_modelo(art, f"W_R_{mes}", modelos["W_R"]); marca("recalibración")
    P = {e: m.predecir(X) for e, m in modelos.items()}
    oficial = "W_R" if "W_R" in P else "W"; nombre_oficial = "W_R (recalibrado con datos ≤ %d)" % modelos[oficial].train_hasta if oficial == "W_R" else "W (congelado)"
    if not historia_ok and modelos[oficial].nivel != "raw":
        log("   ⚠ faltan los 2 meses de historia: modo degradado, el score oficial es el baseline A")
        oficial, nombre_oficial = "A", "A (baseline; modo degradado por falta de historia)"
    p = P[oficial]; marca("predicción")

    # ---- corte (el % se aprende sólo de meses ya etiquetados)
    previas = [h["realizado"]["frac_opt"] for h in hist if h.get("realizado") and h["mes"] + C.GAP <= mes]
    frac = frac_previa(previas, man["frac_recomendada"]); k = int(round(frac * n))
    out = pd.DataFrame({ID: X.index, "probabilidad": p, **{f"prob_{e}": v for e, v in P.items()}})
    out = out.sort_values("probabilidad", ascending=False).reset_index(drop=True)
    for mult in C.CORTES_MULT: out[f"enviar_{int(round(100 * mult))}"] = (out.index < int(round(frac * mult * n))).astype(int)
    out["enviar"] = (out.index < k).astype(int)
    top = lambda col: set(out.sort_values(col, ascending=False)[ID].head(k))
    solape = {e: len(top(f"prob_{e}") & top("probabilidad")) / max(k, 1) for e in P if e != oficial}

    # ---- chequeos de drift + ALERTAS + decisión
    rep = reporte(perfil, vista(fuente[mes], spec, mes), p, imp_base=imp_base); al = alarmas(rep, ch_mes)
    previo = next((h for h in hist if h["mes"] == mes_menos(mes, C.GAP) and h.get("realizado")), None)
    ult = max([h["mes"] for h in hist if h["mes"] < mes and (h.get("decision") or {}).get("accion") == "reentrenar"], default=None)
    desde = 99 if ult is None else len(rango_meses(ult, mes)) - 1
    ac = decidir(al, previo["realizado"]["auc"] if previo else None, man["auc_referencia"], desde)
    info = dict(mes=mes, run_id=run_id, modo=modo, modelo_oficial=nombre_oficial, historia_ok=historia_ok, n_clientes=n, n_envios=k, frac_envio=frac,
                solape_con_oficial=solape, drift={a: b for a, b in rep.items() if a != "psi_todas"}, psi_todas=rep["psi_todas"], alarma=al, decision=ac,
                calidad={a: b for a, b in ch_mes.items()}, score=resumen_score(p), tiempos=tiempos, entrenado_hasta=modelos[oficial].train_hasta,
                estrategias=sorted(P), generado=bundle.ahora())
    if conclase and CLASE in fuente[mes].columns and fuente[mes][CLASE].notna().any():
        info.update(_realizado(fuente[mes][CLASE], out, previas, oficial))
    info["total_s"] = round(time.time() - t0, 1); info["dentro_del_limite"] = info["total_s"] < C.LIMITE_SCORING_S
    io_.escribir_csv(io_.unir(art, "produccion", f"score_{mes}.csv"), out, index=False)
    io_.escribir_json(io_.unir(art, "produccion", f"monitor_{mes}.json"), info)
    hist = [h for h in hist if h["mes"] != mes] + [info]; hist.sort(key=lambda h: h["mes"]); _guardar_historial(art, hist); marca("salidas")
    if dashboard:
        from . import dashboard as dash
        dash.generar(art, log=log)
    log(f"Producción {mes}: {n:,} clientes | envíos {k:,} ({100 * frac:.2f}%) | alarma {al['nivel']} -> {ac['accion']} | {info['total_s']}s")
    return info

def _realizado(clase, out, previas, oficial):
    c = clase.reindex(pd.Index(out[ID])); ok = c.notna().to_numpy(); y = (c == "BAJA+2").to_numpy().astype(int)
    rr = metricas(y[ok], out.probabilidad.to_numpy()[ok]); rr.update(reglas_mes(rr, previas))
    est = {col[5:]: {k_: v for k_, v in metricas(y[ok], out[col].to_numpy()[ok]).items() if k_ in ("auc", "ap", "ganancia_opt", "lift10")}
           for col in out.columns if col.startswith("prob_")}
    return dict(realizado=rr, realizado_estrategias=est)

def cerrar(mes, run_id=None, log=print):
    """CIERRE DE MES: cuando ya llegó la clase (mes+2), completa las métricas reales del score que se entregó en `mes`."""
    run_id = run_id or bundle.ultimo_run(C.ART_URI); art = io_.unir(C.ART_URI, run_id)
    with io_.abrir(io_.unir(art, "produccion", f"score_{mes}.csv"), "rb") as f: out = pd.read_csv(f)
    df = leer_meses_con_historia([mes, mes_menos(mes, -1), mes_menos(mes, -2)])
    assert all(m in set(df[MES].astype(int)) for m in (mes_menos(mes, -1), mes_menos(mes, -2))), f"todavía no llegaron los meses {mes_menos(mes, -1)} y {mes_menos(mes, -2)}"
    clase = agregar_clase(df[[ID, MES]].copy()); clase = clase[clase[MES] == mes].set_index(ID)[CLASE]
    hist = _historial(art); h = next(x for x in hist if x["mes"] == mes)
    previas = [x["realizado"]["frac_opt"] for x in hist if x.get("realizado") and x["mes"] + C.GAP <= mes]
    h.update(_realizado(clase, out, previas, "W")); _guardar_historial(art, hist)
    from . import dashboard as dash
    dash.generar(art, log=log)
    log(f"Cierre {mes}: AUC realizado {h['realizado']['auc']:.3f}")
    return h
