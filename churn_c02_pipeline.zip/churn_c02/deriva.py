"""Data drifting: PSI por variable, AUC adversarial y PSI del score contra un perfil de referencia guardado en el bundle
(producción no necesita los datos de entrenamiento)."""
import numpy as np, pandas as pd
import lightgbm as lgb
from sklearn.metrics import roc_auc_score
from .config import C

def psi_arr(esperado_prop, edges, act):
    act = act[~np.isnan(act)]
    if len(act) < 50: return np.nan
    b = np.histogram(act, edges)[0] / len(act)
    a, b = np.clip(esperado_prop, 1e-4, None), np.clip(b, 1e-4, None)
    return float(((b - a) * np.log(b / a)).sum())

TENDENCIA = ("cliente_antiguedad", "cliente_edad")    # crecen solas con el calendario: su corrimiento es esperado, no es deriva

def vista(df, spec, mes):
    """Vista del mes sobre la que se mide la deriva (en generación y en producción): variables crudas (fechas ya relativas al mes),
    sin las de tendencia y, si hay IPC, con los montos en pesos constantes. Sin esto la inflación (~3% mensual) y el calendario
    hacen que 'todo se mueva' y las alarmas se prendan siempre. Si falta el IPC del mes, los montos quedan fuera de la medición."""
    excl = TENDENCIA if spec.get("fechas") is not None else ()
    v = df[[c for c in spec["base"] if c in df.columns and c not in excl]].astype("float64")
    fac = spec.get("ipc") if spec.get("deriva_ipc") else None      # bundles viejos (sin la marca) siguen midiendo en pesos corrientes
    if fac:
        f = fac.get(str(mes))
        mont = [c for c in spec["montos"] if c in v.columns]
        v[mont] = v[mont] * f if f is not None else np.nan
    return v

def psi_scores(p_ref, p, bins=10):
    e = np.unique(np.quantile(p_ref, np.linspace(0, 1, bins + 1))); e[0], e[-1] = -np.inf, np.inf
    return psi_arr(np.histogram(p_ref, e)[0] / len(p_ref), e, np.asarray(p, float))

class Perfil:
    """Referencia de lo que el modelo 'vio': deciles de cada variable cruda, muestra de clientes y distribución del score."""
    def __init__(self, muestras, bins=10, max_muestra=20000, seed=0):
        ref = pd.concat(muestras)
        self.cols = list(ref.columns); self.edges, self.props = {}, {}
        for c in self.cols:
            x = ref[c].to_numpy("float64"); x = x[~np.isnan(x)]
            if len(x) < 50: continue
            e = np.unique(np.quantile(x, np.linspace(0, 1, bins + 1)))
            if len(e) < 3: continue
            e[0], e[-1] = -np.inf, np.inf
            self.edges[c], self.props[c] = e, np.histogram(x, e)[0] / len(x)
        self.muestra = ref.sample(min(max_muestra, len(ref)), random_state=seed)
        self.score_edges, self.score_props = None, None
        self.ref_calidad = None

    def fijar_score(self, p_ref, bins=10):
        e = np.unique(np.quantile(p_ref, np.linspace(0, 1, bins + 1))); e[0], e[-1] = -np.inf, np.inf
        self.score_edges, self.score_props = e, np.histogram(p_ref, e)[0] / len(p_ref)

    def psi_vars(self, df):
        return pd.Series({c: psi_arr(self.props[c], self.edges[c], df[c].to_numpy("float64")) for c in self.edges if c in df.columns}, dtype=float).dropna()

    def psi_score(self, p):
        return psi_arr(self.score_props, self.score_edges, np.asarray(p, float)) if self.score_edges is not None else np.nan

    def adversarial(self, df, n=6000, seed=0):
        """AUC de un modelo que intenta distinguir 'cliente de este mes' de 'cliente de la ventana de entrenamiento'. 0,5 = igual."""
        cols = [c for c in self.cols if c in df.columns and df[c].notna().any() and self.muestra[c].notna().any()]   # una columna toda NaN de un lado delataría el mes
        a, b = self.muestra[cols].sample(min(n, len(self.muestra)), random_state=seed), df[cols].sample(min(n, len(df)), random_state=seed + 1)
        X, y = pd.concat([a, b]), np.r_[np.zeros(len(a)), np.ones(len(b))]
        idx = np.random.default_rng(seed).permutation(len(X)); cut = len(X) // 2
        p = {**C.LGB_DEFAULT, "num_leaves": 15, "min_data_in_leaf": 50, "num_threads": C.NUM_HILOS}
        m = lgb.train(p, lgb.Dataset(X.iloc[idx[:cut]], label=y[idx[:cut]]), 80)
        return float(roc_auc_score(y[idx[cut:]], m.predict(X.iloc[idx[cut:]])))

def reporte(perfil, df, p=None, adversarial=True, top=25, imp_base=None):
    from . import calidad
    ps = perfil.psi_vars(df)
    out = dict(psi_medio=float(ps.mean()), n_vars=int(len(ps)), n_psi10=int((ps > .1).sum()), n_psi25=int((ps > .25).sum()),
               frac_psi25=float((ps > .25).mean()), top=[[k, round(float(v), 3)] for k, v in ps.sort_values(ascending=False).head(top).items()],
               psi_todas=ps.round(4).to_dict())
    if imp_base:
        out["psi_pond"] = calidad.psi_ponderado(ps, imp_base); tm = calidad.top_movidas(ps, imp_base)
        out["top_movidas"], out["n_top_movidas"] = tm, len(tm)
    out["adv"] = perfil.adversarial(df) if adversarial else None
    out["psi_score"] = perfil.psi_score(p) if p is not None else None
    return out
