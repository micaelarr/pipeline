#!/usr/bin/env bash
# Generación con estrategias en paralelo. Cada línea con '&' puede correr en una VM distinta (todas comparten ART_URI en un bucket y
# C02_RUN). Las etapas terminadas dejan un json en <ART_URI>/<run>/etapas/: si se corta, se relanza lo que falte.
set -euo pipefail
export C02_RUN=${C02_RUN:-gen_$(date +%Y%m%d)}
export C02_DATA=${C02_DATA:-/data/competencia_02_pq} C02_ARTEFACTOS=${C02_ARTEFACTOS:-gs://MI_BUCKET/churn_c02/artefactos}
export C02_CACHE=${C02_CACHE:-/data/cache} C02_IPC=${C02_IPC:-/data/ipc.csv} C02_OPTUNA_TRIALS=${C02_OPTUNA_TRIALS:-60}
# (opcional) BO distribuida: export C02_OPTUNA_STORAGE=postgresql://usuario:clave@host/optuna   y lanzar 'optuna' en varias VMs
python3 -m churn_c02.etapas preparar --run $C02_RUN                                   # 1) tablas + chequeos (una vez)
for E in A B C D; do python3 -m churn_c02.etapas estrategia $E --run $C02_RUN & done; wait   # 2) estrategias EN PARALELO
python3 -m churn_c02.etapas optuna --run $C02_RUN                                     # 3) selección (sólo 2019) + Optuna
python3 -m churn_c02.etapas politica W --run $C02_RUN                                 # 4) modelo W congelado + monitor
python3 -m churn_c02.etapas politica W_R --run $C02_RUN & python3 -m churn_c02.etapas politica W_T --run $C02_RUN & wait   # 5) recalibrado | reentrenado
python3 -m churn_c02.etapas consolidar --run $C02_RUN                                 # 6) bundle + dashboard
