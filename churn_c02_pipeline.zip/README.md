# churn_c02 · pipeline de generación + pipeline de producción

Competencia 2: modelo estable en una ventana temporal (train 201901–201912, pandemia en 2020), siempre comparado contra otro modelo, con score + métricas (dashboard) + estrategias.

## Flujo (según las sugerencias de los profesores)
**Input → Feature engineering → Chequeos → Alertas (dashboard) → Correcciones**, igual en generación y producción (`churn_c02/calidad.py`):
- *Chequeos:* % de nulos y de ceros contra referencia, variables constantes, **meses rotos** (todo nulo / todo ceros / salto de nulos vs mes anterior), columnas faltantes o nuevas, filas, clientes duplicados, y **PSI usado con criterio**: ponderado por la importancia de cada variable en el modelo + cuántas de las 15 variables más importantes se movieron (el % de variables movidas es sólo informativo). Una alerta sobre una variable importante sube de nivel.
- *Alertas:* van al dashboard (sección «Calidad de datos» y tarjeta por mes) y al monitor.
- *Correcciones:* variable rota → NaN en ese mes (sin inventar valores); columna faltante → columna NaN; si una variable está rota ≥2 de los últimos 3 meses, el pipeline **recomienda excluirla** y recalibrar sin ella.

## Estrategias y políticas
- **A** baseline · **B** + lags/deltas/razones/ventana 3m · **C** + percentiles dentro del mes + pesos por mes + 3 semillas · **D** B + montos en pesos constantes (IPC; sólo si hay `C02_IPC`).
- **Congelar** = **W** (ganadora con Optuna). **Recalibrar** = **W_R**: mismos hiperparámetros, ventana móvil de datos nuevos. **Reentrenar** = **W_T**: vuelve a correr la generación con Optuna cuando el monitor lo pide.
- **IPC:** `ipc_template.csv` muestra el formato (`foto_mes, ipc`, nivel general de cualquier base). El dashboard compara sin tratar (B), IPC (D) y percentiles (C): columnas «D − B» y «C − D». Meses sin IPC se extrapolan con la inflación de los últimos 3 meses y se avisa.

## Generación (offline, Google Cloud) — estrategias en paralelo
Etapas independientes (`churn_c02/etapas.py`), cada una un proceso/script:
`preparar → estrategia A | B | C | D (paralelo) → optuna → política W → política W_R | W_T (paralelo) → consolidar`.
- Todo junto: `python3 run_generacion.py <run_id> [--paralelo]`. Por etapas / en VMs distintas: `gcp_paralelo.sh` (`python3 -m churn_c02.etapas estrategia A --run <run_id>`).
- **Corrida cortada:** relanzar con el mismo `run_id`; se saltean las etapas terminadas (cada una deja un json en `<ART_URI>/<run_id>/etapas/`). Optuna también retoma sus trials (sqlite, o `C02_OPTUNA_STORAGE` para BO distribuida).
- **Meses (alineado con las diapositivas):** la BO valida en 201909 y 201911; las estrategias se comparan en walk-forward 2019 con 201912 como mes que la BO nunca vio; reentrenamiento final con 201901–201912; 2020 es prueba ciega.

## Producción (rápida) — `python3 run_produccion.py <mes> [score|recalibrar] [--nuevo archivo.csv]`
1. Carga el bundle (no lee datos de entrenamiento). 2. Lee **3 meses**; si el mes llega aparte (`--nuevo`) se valida y se **agrega a la historia** (`C02_HISTORIA`, un csv.gz por mes; si llega corregido, reemplaza). 3. Chequeos → alertas → correcciones. 4. Variables (mismo código). 5. Puntúa con **N estrategias** (A, B, C, D, W…). 6. Decide *score / recalibrar / reentrenar*. 7. Exporta score con varios cortes (`enviar_80/100/120`), monitor y dashboard.
- **Cierre de mes:** `python3 run_produccion.py cerrar 202008` — cuando llegó la clase (mes+2) completa las métricas reales (AUC, ganancia, etc.) de lo que se entregó.
- Sin los 2 meses de historia: modo degradado con el baseline A (avisa).

## Control de leak
1. La clase de T se conoce en T+2: ningún modelo entrena con clase > T−2 (se audita). 2. Variables causales (test que borra los meses futuros). 3. Selección de estrategia y Optuna sólo con 2019; 2020 ciega. 4. Perfil de drift, referencia de calidad y corte por % sólo con información ya disponible; detección de meses rotos causal. 5. LLM opcional (`C02_LLM=anthropic`): sólo redacta con métricas agregadas «a la fecha»; no ve clientes, ni clases futuras, ni toca score o variables.

## Archivos
`churn_c02/` (módulos) · `run_generacion.py` · `run_produccion.py` · `prepare_parquet.py` · `gcp_run.sh` · `gcp_paralelo.sh` · `ipc_template.csv` · `notebooks/` · `requirements.txt` · `dashboard_demo_datos_sinteticos.html`. Configuración por variables `C02_*` (ver `churn_c02/config.py`).

## Límites
Probado de punta a punta con datos sintéticos (con meses rotos inyectados) y reemplazos simplificados de LightGBM/Optuna; **no** corrió con el dataset real ni con las librerías reales. Los umbrales de alarma (`ALARMA_*`, `Q_*`) hay que ajustarlos con datos reales. No hay archivo de IPC incluido: hay que cargar el de INDEC.

## Revisión (nov-2026) — qué se corrigió después de la corrida gen1
1. **Calibración**: `estrategias.corregir` tenía la fórmula invertida (calib 28–109, regla p > 2,5% contactaba al 66–100%). Corregida.
2. **Submuestreo**: BAJA+1 se guardaba entero y quedaba 3,3× sobrerrepresentado entre los negativos; ahora todos los negativos van a la misma tasa (la corrección de probabilidad es exacta).
3. **Fechas de tarjeta** (`fultimo_cierre`, `Finiciomora`, `Fvencimiento`, `fechaalta`): venían ancladas al mes y hacían que el AUC adversarial diera 1,0 hasta en 2019, que `Finiciomora` "se moviera" todos los meses y que el monitor alarmara (nivel 2) en los 12 meses de 2020. Ahora se expresan relativas a la moda del propio mes (`variables.normalizar_fechas`), antes de los chequeos, en generación y en producción.
4. **Deriva en pesos constantes**: el PSI y el AUC adversarial se miden sobre `deriva.vista` (montos deflactados por IPC, sin `cliente_antiguedad`/`cliente_edad`, que crecen solas). Columnas todas NaN (variables rotas) se excluyen del adversarial.
5. **Corte en 2020**: W, W_R y W_T arrancan con las fracciones óptimas del walk-forward 2019 (lo mismo que `frac_recomendada` en producción) en vez de caer a p > 2,5%. La fracción se acota a [0,25%; 15%].
6. **Optuna**: 1 semilla durante la búsqueda (la C final sigue con 3) y poda de trials malos tras el primer mes de validación (MedianPruner): ~3× más rápido.
7. **Producción**: cuenta los meses desde el último "reentrenar" (antes siempre 99) y marca "importante" sólo a las variables del top-15.
Bundles viejos (gen1) siguen funcionando en producción con el comportamiento anterior; para tener todo lo nuevo hay que correr una generación nueva con otro run_id.
8. **(tras gen2) AUC adversarial informativo**: dio 0,97–0,99 ya en 2019, cuando el modelo funcionaba bien, así que no discrimina; ya no dispara alarmas (se puede reactivar con `C02_ALARMA_ADV=1`). El monitor queda con PSI del score, PSI ponderado, top-15 movidas y calidad.
9. **(tras gen2) Reentrenar parte de los hiperparámetros vigentes**: el Optuna de reentrenamiento arranca desde los parámetros del campeón, no desde el default de LightGBM.
