"""Pipeline de GENERACIÓN. Uso:  python3 run_generacion.py [run_id] [--paralelo] [--forzar]
--paralelo : lanza las estrategias (y W_R / W_T) como procesos separados al mismo tiempo.
Si una corrida se corta, volver a lanzar con el mismo run_id: se saltean las etapas ya terminadas.
Etapas sueltas (para repartirlas en VMs distintas): python3 -m churn_c02.etapas <etapa> [arg] --run <run_id>   (ver gcp_paralelo.sh)"""
import sys
from churn_c02 import generacion
if __name__ == "__main__":
    a = [x for x in sys.argv[1:] if not x.startswith("--")]
    generacion.run(a[0] if a else None, paralelo="--paralelo" in sys.argv, forzar="--forzar" in sys.argv)
