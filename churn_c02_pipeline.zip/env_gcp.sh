# Variables para correr en la VM:  source env_gcp.sh
export BUCKET=gs://micaelarrodriguez98_buckito2026          # verificá que el nombre sea exacto
export C02_DATA=/data/competencia_02_pq                     # carpeta parquet que genera prepare_parquet.py
export C02_ARTEFACTOS=/data/artefactos                      # local (rápido); se sincroniza al bucket con sync_bucket.sh
export C02_HISTORIA=/data/historia
export C02_CACHE=/data/cache
export C02_IPC=/data/ipc.csv                                # IPC nivel general INDEC (base dic-2016=100), ya incluido: cp ipc.csv /data/
export C02_HILOS=3                                          # 4 estrategias en paralelo × 3 hilos = 12 vCPU
export C02_OPTUNA_TRIALS=60
