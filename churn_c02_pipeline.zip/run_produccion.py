"""Pipeline de PRODUCCIÓN.
  python3 run_produccion.py 202008                      # score con los modelos congelados
  python3 run_produccion.py 202008 recalibrar           # mismos hiperparámetros, datos recientes
  python3 run_produccion.py 202008 score --nuevo mes.csv  # el mes llega en crudo desde un archivo aparte (se agrega a la historia)
  python3 run_produccion.py 202008 score --evaluar      # sólo demostración: el mes ya tiene clase en los datos
  python3 run_produccion.py cerrar 202008               # cierre de mes: llegó la clase, completa las métricas reales"""
import sys
from churn_c02 import produccion
if __name__ == "__main__":
    a = sys.argv[1:]
    if a[0] == "cerrar": produccion.cerrar(int(a[1]))
    else:
        mes = int(a[0]); modo = a[1] if len(a) > 1 and not a[1].startswith("--") else "score"
        produccion.run(mes, modo, uri_mes_nuevo=a[a.index("--nuevo") + 1] if "--nuevo" in a else None, evaluar="--evaluar" in a)
