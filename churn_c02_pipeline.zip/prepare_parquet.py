"""Una vez, en la VM: csv -> parquet particionado por foto_mes (leer un mes pasa de minutos a segundos).
Uso: python3 prepare_parquet.py /data/competencia_02.csv /data/competencia_02_pq   (luego: export C02_DATA=/data/competencia_02_pq)"""
import sys
from churn_c02.datos import csv_a_parquet
print(csv_a_parquet(sys.argv[1], sys.argv[2]))
