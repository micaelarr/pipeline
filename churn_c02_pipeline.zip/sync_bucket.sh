#!/usr/bin/env bash
# Copia los resultados de la VM al bucket cada 5 minutos (para no perder nada si se borra la VM).
# Uso:  source env_gcp.sh && nohup ./sync_bucket.sh > sync.log 2>&1 &
while true; do
  gcloud storage rsync -r /data/artefactos $BUCKET/churn_c02/artefactos
  gcloud storage rsync -r /data/historia $BUCKET/churn_c02/historia 2>/dev/null || true
  sleep 300
done
