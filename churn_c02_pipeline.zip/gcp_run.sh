#!/usr/bin/env bash
# Ejemplo de corrida en una VM de Google Cloud (Compute Engine / Vertex AI Workbench). Ajustá bucket y rutas.
set -euo pipefail
BUCKET=gs://MI_BUCKET/churn_c02
mkdir -p /data && gsutil -m cp $BUCKET/competencia_02.csv /data/            # 1) datos al disco local de la VM
pip install -r requirements.txt
python3 prepare_parquet.py /data/competencia_02.csv /data/competencia_02_pq   # 2) parquet por mes (una sola vez)
export C02_DATA=/data/competencia_02_pq C02_ARTEFACTOS=$BUCKET/artefactos C02_CACHE=/data/cache
export C02_OPTUNA_TRIALS=60                                                  # 3) GENERACIÓN (con Optuna)
python3 run_generacion.py
python3 run_produccion.py 202008 score --evaluar                             # 4) PRODUCCIÓN de un mes (rápido)
# python3 run_produccion.py 202008 recalibrar --evaluar                      #    recalibrar: mismos parámetros, datos nuevos
# python3 run_generacion.py                                                  #    reentrenar: volver a correr la generación
